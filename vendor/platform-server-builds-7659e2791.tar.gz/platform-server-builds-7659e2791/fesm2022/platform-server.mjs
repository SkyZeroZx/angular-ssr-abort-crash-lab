/**
 * @license Angular v22.4.0-next.0+sha-f3ea683
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

import { PLATFORM_SERVER_PROVIDERS, PlatformState, BEFORE_APP_SERIALIZED, resolveUrl, platformServer, INITIAL_CONFIG, createScript } from './_server-chunk.mjs';
export { ServerModule, DominoAdapter as ɵDominoAdapter, ENABLE_DOM_EMULATION as ɵENABLE_DOM_EMULATION, INTERNAL_SERVER_PLATFORM_PROVIDERS as ɵINTERNAL_SERVER_PLATFORM_PROVIDERS, SERVER_RENDER_PROVIDERS as ɵSERVER_RENDER_PROVIDERS } from './_server-chunk.mjs';
import { makeEnvironmentProviders, InjectionToken, ɵstartMeasuring as _startMeasuring, ɵstopMeasuring as _stopMeasuring, ApplicationRef, ɵINTERNAL_APPLICATION_ERROR_HANDLER as _INTERNAL_APPLICATION_ERROR_HANDLER, ɵRuntimeError as _RuntimeError, ɵIS_HYDRATION_DOM_REUSE_ENABLED as _IS_HYDRATION_DOM_REUSE_ENABLED, ɵannotateForHydration as _annotateForHydration, CSP_NONCE, APP_ID, Renderer2, ɵSSR_CONTENT_INTEGRITY_MARKER as _SSR_CONTENT_INTEGRITY_MARKER, Version } from '@angular/core';
import { ɵHTTP_FETCH_MAX_RESPONSE_SIZE as _HTTP_FETCH_MAX_RESPONSE_SIZE } from '@angular/common/http';
import '@angular/common';
import '@angular/platform-browser';
import '../third_party/domino/bundled-domino.mjs';
import 'rxjs';

function provideServerRendering(options) {
  if (typeof ngServerMode === 'undefined') {
    globalThis['ngServerMode'] = true;
  }
  const providers = [...PLATFORM_SERVER_PROVIDERS];
  if (options?.maxResponseBodySize) {
    providers.push({
      provide: _HTTP_FETCH_MAX_RESPONSE_SIZE,
      useValue: options.maxResponseBodySize
    });
  }
  return makeEnvironmentProviders(providers);
}

const EVENT_DISPATCH_SCRIPT_ID = 'ng-event-dispatch-contract';
function createServerPlatform(options) {
  const extraProviders = options.platformProviders ?? [];
  const measuringLabel = 'createServerPlatform';
  _startMeasuring(measuringLabel);
  const {
    document,
    url
  } = options;
  const platform = platformServer([{
    provide: INITIAL_CONFIG,
    useValue: {
      document,
      url
    }
  }, extraProviders]);
  _stopMeasuring(measuringLabel);
  return platform;
}
function findEventDispatchScript(doc) {
  return doc.getElementById(EVENT_DISPATCH_SCRIPT_ID);
}
function removeEventDispatchScript(doc) {
  findEventDispatchScript(doc)?.remove();
}
function prepareForHydration(platformState, applicationRef) {
  const measuringLabel = 'prepareForHydration';
  _startMeasuring(measuringLabel);
  const environmentInjector = applicationRef.injector;
  const doc = platformState.getDocument();
  if (!environmentInjector.get(_IS_HYDRATION_DOM_REUSE_ENABLED, false)) {
    removeEventDispatchScript(doc);
    return;
  }
  appendSsrContentIntegrityMarker(doc);
  const eventTypesToReplay = _annotateForHydration(applicationRef, doc);
  if (eventTypesToReplay.regular.size || eventTypesToReplay.capture.size) {
    insertEventRecordScript(environmentInjector.get(APP_ID), doc, eventTypesToReplay, environmentInjector.get(CSP_NONCE, null));
  } else {
    removeEventDispatchScript(doc);
  }
  _stopMeasuring(measuringLabel);
}
function appendSsrContentIntegrityMarker(doc) {
  const comment = doc.createComment(_SSR_CONTENT_INTEGRITY_MARKER);
  doc.body.firstChild ? doc.body.insertBefore(comment, doc.body.firstChild) : doc.body.append(comment);
}
function appendServerContextInfo(applicationRef) {
  const injector = applicationRef.injector;
  let serverContext = sanitizeServerContext(injector.get(SERVER_CONTEXT, DEFAULT_SERVER_CONTEXT));
  applicationRef.components.forEach(componentRef => {
    const renderer = componentRef.injector.get(Renderer2);
    const element = componentRef.location.nativeElement;
    if (element) {
      renderer.setAttribute(element, 'ng-server-context', serverContext);
    }
  });
}
function insertEventRecordScript(appId, doc, eventTypesToReplay, nonce) {
  const measuringLabel = 'insertEventRecordScript';
  _startMeasuring(measuringLabel);
  const {
    regular,
    capture
  } = eventTypesToReplay;
  const eventDispatchScript = findEventDispatchScript(doc);
  if (eventDispatchScript) {
    const replayScriptContents = `window.__jsaction_bootstrap(` + `document.body,` + `"${appId}",` + `${JSON.stringify(Array.from(regular))},` + `${JSON.stringify(Array.from(capture))}` + `);`;
    const replayScript = createScript(doc, replayScriptContents, nonce);
    eventDispatchScript.after(replayScript);
  }
  _stopMeasuring(measuringLabel);
}
async function renderInternal(platformRef, applicationRef) {
  if (platformRef.destroyed || applicationRef.destroyed) {
    return '';
  }
  const platformState = platformRef.injector.get(PlatformState);
  prepareForHydration(platformState, applicationRef);
  appendServerContextInfo(applicationRef);
  const environmentInjector = applicationRef.injector;
  const errorHandler = environmentInjector.get(_INTERNAL_APPLICATION_ERROR_HANDLER);
  const callbacks = environmentInjector.get(BEFORE_APP_SERIALIZED, null);
  if (callbacks) {
    const asyncCallbacks = [];
    for (const callback of callbacks) {
      try {
        const callbackResult = callback();
        if (callbackResult) {
          asyncCallbacks.push(callbackResult);
        }
      } catch (e) {
        if (!environmentInjector.destroyed) {
          errorHandler(e);
        }
      }
    }
    if (asyncCallbacks.length) {
      if (platformRef.destroyed || applicationRef.destroyed) {
        void Promise.allSettled(asyncCallbacks);
        return '';
      }
      const settled = await new Promise(resolve => {
        const unregisterDestroy = applicationRef.onDestroy(() => {
          resolve(null);
        });
        Promise.allSettled(asyncCallbacks).then(results => {
          unregisterDestroy();
          resolve(results);
        });
      });
      if (settled === null) {
        return '';
      }
      for (const result of settled) {
        if (result.status === 'rejected' && !environmentInjector.destroyed) {
          errorHandler(result.reason);
        }
      }
    }
  }
  if (platformRef.destroyed || applicationRef.destroyed) {
    return '';
  }
  return platformState.renderToString();
}
function asyncDestroyPlatform(platformRef) {
  if (platformRef.destroyed) {
    return Promise.resolve();
  }
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      try {
        if (!platformRef.destroyed) {
          platformRef.destroy();
        }
        resolve();
      } catch (error) {
        reject(error);
      }
    }, 0);
  });
}
const DEFAULT_SERVER_CONTEXT = 'other';
const SERVER_CONTEXT = new InjectionToken('SERVER_CONTEXT');
function sanitizeServerContext(serverContext) {
  const context = serverContext.replace(/[^a-zA-Z0-9\-]/g, '');
  return context.length > 0 ? context : DEFAULT_SERVER_CONTEXT;
}
async function renderModule(moduleType, options) {
  const {
    document,
    url,
    extraProviders: platformProviders,
    allowedHosts
  } = options;
  validateAllowedHosts(url, allowedHosts);
  const platformRef = createServerPlatform({
    document,
    url,
    platformProviders
  });
  try {
    const moduleRef = await platformRef.bootstrapModule(moduleType);
    if (platformRef.destroyed || moduleRef.injector.destroyed) {
      return '';
    }
    const applicationRef = moduleRef.injector.get(ApplicationRef);
    const measuringLabel = 'whenStable';
    _startMeasuring(measuringLabel);
    await applicationRef.whenStable();
    _stopMeasuring(measuringLabel);
    return await renderInternal(platformRef, applicationRef);
  } finally {
    await asyncDestroyPlatform(platformRef);
  }
}
async function renderApplication(bootstrap, options) {
  const renderAppLabel = 'renderApplication';
  const bootstrapLabel = 'bootstrap';
  const _renderLabel = '_render';
  const {
    url,
    allowedHosts
  } = options;
  validateAllowedHosts(url, allowedHosts);
  _startMeasuring(renderAppLabel);
  const platformRef = createServerPlatform(options);
  try {
    _startMeasuring(bootstrapLabel);
    const applicationRef = await bootstrap({
      platformRef
    });
    _stopMeasuring(bootstrapLabel);
    if (platformRef.destroyed || applicationRef.destroyed) {
      return '';
    }
    _startMeasuring(_renderLabel);
    const measuringLabel = 'whenStable';
    _startMeasuring(measuringLabel);
    await applicationRef.whenStable();
    _stopMeasuring(measuringLabel);
    const rendered = await renderInternal(platformRef, applicationRef);
    _stopMeasuring(_renderLabel);
    return rendered;
  } finally {
    try {
      await asyncDestroyPlatform(platformRef);
    } finally {
      _stopMeasuring(renderAppLabel);
    }
  }
}
function validateAllowedHosts(url, allowedHosts) {
  if (typeof url === 'string') {
    const parsedUrl = resolveUrl(url);
    if (parsedUrl !== null) {
      const hostname = parsedUrl.hostname;
      const allowedHostsSet = new Set(allowedHosts);
      if (!isHostAllowed(hostname, allowedHostsSet)) {
        throw new _RuntimeError(5706, typeof ngDevMode === 'undefined' || ngDevMode ? `Host ${url} is not allowed. You can configure \`allowedHosts\` option.` : url);
      }
    }
  }
}
function isHostAllowed(hostname, allowedHosts) {
  if (allowedHosts.has('*') || allowedHosts.has(hostname)) {
    return true;
  }
  for (const allowedHost of allowedHosts) {
    if (!allowedHost.startsWith('*.')) {
      continue;
    }
    const domain = allowedHost.slice(1);
    if (hostname.endsWith(domain)) {
      return true;
    }
  }
  return false;
}

const VERSION = /* @__PURE__ */new Version('22.4.0-next.0+sha-f3ea683');

export { BEFORE_APP_SERIALIZED, INITIAL_CONFIG, PlatformState, VERSION, platformServer, provideServerRendering, renderApplication, renderModule, SERVER_CONTEXT as ɵSERVER_CONTEXT, isHostAllowed as ɵisHostAllowed, renderInternal as ɵrenderInternal };
//# sourceMappingURL=platform-server.mjs.map
