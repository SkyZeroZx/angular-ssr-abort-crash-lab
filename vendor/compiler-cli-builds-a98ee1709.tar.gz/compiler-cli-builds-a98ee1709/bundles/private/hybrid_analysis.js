
      import {createRequire as __cjsCompatRequire} from 'module';
      const require = __cjsCompatRequire(import.meta.url);
    
import {
  AbsoluteSourceSpan,
  IdentifierKind,
  IndexingContext,
  PotentialTopLevelReadsVisitor,
  extractHmrDependenciesFromOutput,
  generateIndexerAnalysis,
  getIndexerTemplateIdentifiers
} from "../chunk-5IEYX442.js";
import {
  Environment,
  ExpressionIdentifier,
  ImportManager,
  RegistryDomSchemaChecker,
  SymbolBuilder,
  SymbolKind,
  findFirstMatchingNode,
  hasExpressionIdentifier
} from "../chunk-MTGRZ4Y6.js";
import {
  ErrorCode,
  validateAndRewriteCoreSymbol
} from "../chunk-JSEB7RQH.js";
import "../chunk-2RWOSWE5.js";
import "../chunk-UTWH365F.js";
import "../chunk-KWAGEHJJ.js";
import "../chunk-IEBNHER4.js";
export {
  AbsoluteSourceSpan,
  Environment,
  ErrorCode,
  ExpressionIdentifier,
  IdentifierKind,
  ImportManager,
  IndexingContext,
  PotentialTopLevelReadsVisitor,
  RegistryDomSchemaChecker,
  SymbolBuilder,
  SymbolKind,
  extractHmrDependenciesFromOutput,
  findFirstMatchingNode,
  generateIndexerAnalysis as generateAnalysis,
  getIndexerTemplateIdentifiers as getTemplateIdentifiers,
  hasExpressionIdentifier,
  validateAndRewriteCoreSymbol
};
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
//# sourceMappingURL=hybrid_analysis.js.map
