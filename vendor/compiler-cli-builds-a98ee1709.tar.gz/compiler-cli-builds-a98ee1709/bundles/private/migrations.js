
      import {createRequire as __cjsCompatRequire} from 'module';
      const require = __cjsCompatRequire(import.meta.url);
    
import {
  DiagnosticCategoryLabel,
  NgCompiler
} from "../chunk-5JMIUAG3.js";
import {
  CompilationMode,
  createForwardRefResolver,
  extractDecoratorQueryMetadata,
  extractTemplate,
  findAngularDecorator,
  getAngularDecorators,
  isShim,
  parseDecoratorInputTransformFunction,
  queryDecoratorNames,
  unwrapExpression
} from "../chunk-Y552PRKN.js";
import {
  DtsMetadataReader,
  DynamicValue,
  FatalDiagnosticError,
  ImportManager,
  PartialEvaluator,
  PotentialImportKind,
  PotentialImportMode,
  Reference,
  ReferenceEmitKind,
  ReferenceEmitter,
  StaticInterpreter,
  SymbolKind,
  TypeScriptReflectionHost,
  getRootDirs,
  reflectObjectLiteral
} from "../chunk-MTGRZ4Y6.js";
import "../chunk-JSEB7RQH.js";
import "../chunk-2RWOSWE5.js";
import {
  getFileSystem,
  isLocalRelativePath
} from "../chunk-UTWH365F.js";
import {
  NodeJSFileSystem
} from "../chunk-KWAGEHJJ.js";
import "../chunk-IEBNHER4.js";
export {
  CompilationMode,
  DiagnosticCategoryLabel,
  DtsMetadataReader,
  DynamicValue,
  FatalDiagnosticError,
  ImportManager,
  NgCompiler,
  NodeJSFileSystem,
  PartialEvaluator,
  PotentialImportKind,
  PotentialImportMode,
  Reference,
  ReferenceEmitKind,
  ReferenceEmitter,
  StaticInterpreter,
  SymbolKind,
  TypeScriptReflectionHost,
  createForwardRefResolver,
  extractDecoratorQueryMetadata,
  extractTemplate,
  findAngularDecorator,
  getAngularDecorators,
  getFileSystem,
  getRootDirs,
  isLocalRelativePath,
  isShim,
  parseDecoratorInputTransformFunction,
  queryDecoratorNames,
  reflectObjectLiteral,
  unwrapExpression
};
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
//# sourceMappingURL=migrations.js.map
