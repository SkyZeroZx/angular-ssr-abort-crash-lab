
      import {createRequire as __cjsCompatRequire} from 'module';
      const require = __cjsCompatRequire(import.meta.url);
    
import {
  getInitializerApiJitTransform
} from "../chunk-Y552PRKN.js";
import {
  ImportedSymbolsTracker,
  TypeScriptReflectionHost
} from "../chunk-MTGRZ4Y6.js";
import "../chunk-JSEB7RQH.js";
import "../chunk-2RWOSWE5.js";
import {
  InvalidFileSystem,
  absoluteFrom,
  basename,
  dirname,
  getFileSystem,
  resolve,
  setFileSystem
} from "../chunk-UTWH365F.js";
import {
  NodeJSFileSystem
} from "../chunk-KWAGEHJJ.js";
import "../chunk-IEBNHER4.js";

// packages/compiler-cli/src/ngtsc/file_system/testing/src/mock_file_system.js
var MockFileSystem = class {
  _isCaseSensitive;
  _fileTree = {};
  _cwd;
  constructor(_isCaseSensitive = false, cwd = "/") {
    this._isCaseSensitive = _isCaseSensitive;
    this._cwd = this.normalize(cwd);
  }
  isCaseSensitive() {
    return this._isCaseSensitive;
  }
  exists(path) {
    return this.findFromPath(path).entity !== null;
  }
  readFile(path) {
    const { entity } = this.findFromPath(path);
    if (isFile(entity)) {
      if (entity instanceof Uint8Array) {
        return new TextDecoder().decode(entity);
      }
      return entity.toString();
    } else {
      throw new MockFileSystemError("ENOENT", path, `File "${path}" does not exist.`);
    }
  }
  readFileBuffer(path) {
    const { entity } = this.findFromPath(path);
    if (isFile(entity)) {
      if (entity instanceof Uint8Array) {
        return entity;
      }
      const encoder = new TextEncoder();
      return encoder.encode(entity);
    } else {
      throw new MockFileSystemError("ENOENT", path, `File "${path}" does not exist.`);
    }
  }
  writeFile(path, data, exclusive = false) {
    const [folderPath, basename2] = this.splitIntoFolderAndFile(path);
    const { entity } = this.findFromPath(folderPath);
    if (entity === null || !isFolder(entity)) {
      throw new MockFileSystemError("ENOENT", path, `Unable to write file "${path}". The containing folder does not exist.`);
    }
    if (exclusive && entity[basename2] !== void 0) {
      throw new MockFileSystemError("EEXIST", path, `Unable to exclusively write file "${path}". The file already exists.`);
    }
    entity[basename2] = data;
  }
  removeFile(path) {
    const [folderPath, basename2] = this.splitIntoFolderAndFile(path);
    const { entity } = this.findFromPath(folderPath);
    if (entity === null || !isFolder(entity)) {
      throw new MockFileSystemError("ENOENT", path, `Unable to remove file "${path}". The containing folder does not exist.`);
    }
    if (isFolder(entity[basename2])) {
      throw new MockFileSystemError("EISDIR", path, `Unable to remove file "${path}". The path to remove is a folder.`);
    }
    delete entity[basename2];
  }
  symlink(target, path) {
    const [folderPath, basename2] = this.splitIntoFolderAndFile(path);
    const { entity } = this.findFromPath(folderPath);
    if (entity === null || !isFolder(entity)) {
      throw new MockFileSystemError("ENOENT", path, `Unable to create symlink at "${path}". The containing folder does not exist.`);
    }
    entity[basename2] = new SymLink(target);
  }
  readdir(path) {
    const { entity } = this.findFromPath(path);
    if (entity === null) {
      throw new MockFileSystemError("ENOENT", path, `Unable to read directory "${path}". It does not exist.`);
    }
    if (isFile(entity)) {
      throw new MockFileSystemError("ENOTDIR", path, `Unable to read directory "${path}". It is a file.`);
    }
    return Object.keys(entity);
  }
  lstat(path) {
    const { entity } = this.findFromPath(path);
    if (entity === null) {
      throw new MockFileSystemError("ENOENT", path, `File "${path}" does not exist.`);
    }
    return new MockFileStats(entity);
  }
  stat(path) {
    const { entity } = this.findFromPath(path, { followSymLinks: true });
    if (entity === null) {
      throw new MockFileSystemError("ENOENT", path, `File "${path}" does not exist.`);
    }
    return new MockFileStats(entity);
  }
  copyFile(from, to) {
    this.writeFile(to, this.readFile(from));
  }
  moveFile(from, to) {
    this.writeFile(to, this.readFile(from));
    const result = this.findFromPath(dirname(from));
    const folder = result.entity;
    const name = basename(from);
    delete folder[name];
  }
  ensureDir(path) {
    const segments = this.splitPath(path).map((segment) => this.getCanonicalPath(segment));
    segments[0] = "";
    if (segments.length > 1 && segments[segments.length - 1] === "") {
      segments.pop();
    }
    let current = this._fileTree;
    for (const segment of segments) {
      if (isFile(current[segment])) {
        throw new Error(`Folder already exists as a file.`);
      }
      if (!current[segment]) {
        current[segment] = {};
      }
      current = current[segment];
    }
    return current;
  }
  removeDeep(path) {
    const [folderPath, basename2] = this.splitIntoFolderAndFile(path);
    const { entity } = this.findFromPath(folderPath);
    if (entity === null || !isFolder(entity)) {
      throw new MockFileSystemError("ENOENT", path, `Unable to remove folder "${path}". The containing folder does not exist.`);
    }
    delete entity[basename2];
  }
  isRoot(path) {
    return this.dirname(path) === path;
  }
  extname(path) {
    const match = /.+(\.[^.]*)$/.exec(path);
    return match !== null ? match[1] : "";
  }
  realpath(filePath) {
    const result = this.findFromPath(filePath, { followSymLinks: true });
    if (result.entity === null) {
      throw new MockFileSystemError("ENOENT", filePath, `Unable to find the real path of "${filePath}". It does not exist.`);
    } else {
      return result.path;
    }
  }
  pwd() {
    return this._cwd;
  }
  chdir(path) {
    this._cwd = this.normalize(path);
  }
  getDefaultLibLocation() {
    let path = "node_modules/typescript/lib";
    let resolvedPath = this.resolve(path);
    const topLevelNodeModules = this.resolve("/" + path);
    while (resolvedPath !== topLevelNodeModules) {
      if (this.exists(resolvedPath)) {
        return resolvedPath;
      }
      path = "../" + path;
      resolvedPath = this.resolve(path);
    }
    return topLevelNodeModules;
  }
  dump() {
    const { entity } = this.findFromPath(this.resolve("/"));
    if (entity === null || !isFolder(entity)) {
      return {};
    }
    return this.cloneFolder(entity);
  }
  init(folder) {
    this.mount(this.resolve("/"), folder);
  }
  mount(path, folder) {
    if (this.exists(path)) {
      throw new Error(`Unable to mount in '${path}' as it already exists.`);
    }
    const mountFolder = this.ensureDir(path);
    this.copyInto(folder, mountFolder);
  }
  cloneFolder(folder) {
    const clone = {};
    this.copyInto(folder, clone);
    return clone;
  }
  copyInto(from, to) {
    for (const path in from) {
      const canonicalPath = this.getCanonicalPath(path);
      Object.defineProperty(to, canonicalPath, {
        configurable: true,
        enumerable: true,
        get: () => {
          const item = from[path];
          let cloned;
          if (isSymLink(item)) {
            cloned = new SymLink(this.getCanonicalPath(item.path));
          } else if (isFolder(item)) {
            cloned = this.cloneFolder(item);
          } else {
            cloned = item;
          }
          Object.defineProperty(to, canonicalPath, {
            configurable: true,
            enumerable: true,
            value: cloned,
            writable: true
          });
          return cloned;
        },
        set: (value) => {
          Object.defineProperty(to, canonicalPath, {
            configurable: true,
            enumerable: true,
            value,
            writable: true
          });
        }
      });
    }
  }
  findFromPath(path, options) {
    const followSymLinks = !!options && options.followSymLinks;
    const segments = this.splitPath(path);
    if (segments.length > 1 && segments[segments.length - 1] === "") {
      segments.pop();
    }
    segments[0] = "";
    let current = this._fileTree;
    while (segments.length) {
      current = current[this.getCanonicalPath(segments.shift())];
      if (current === void 0) {
        return { path, entity: null };
      }
      if (segments.length > 0) {
        if (isFile(current)) {
          current = null;
          break;
        }
        if (isSymLink(current)) {
          return this.findFromPath(resolve(current.path, ...segments), { followSymLinks });
        }
      }
      if (isFile(current)) {
        break;
      }
      if (isSymLink(current)) {
        if (followSymLinks) {
          return this.findFromPath(resolve(current.path, ...segments), { followSymLinks });
        } else {
          break;
        }
      }
    }
    return { path, entity: current };
  }
  splitIntoFolderAndFile(path) {
    const segments = this.splitPath(this.getCanonicalPath(path));
    const file = segments.pop();
    return [path.substring(0, path.length - file.length - 1), file];
  }
  getCanonicalPath(p3) {
    return this.isCaseSensitive() ? p3 : p3.toLowerCase();
  }
};
var SymLink = class {
  path;
  constructor(path) {
    this.path = path;
  }
};
var MockFileStats = class {
  entity;
  constructor(entity) {
    this.entity = entity;
  }
  isFile() {
    return isFile(this.entity);
  }
  isDirectory() {
    return isFolder(this.entity);
  }
  isSymbolicLink() {
    return isSymLink(this.entity);
  }
};
var MockFileSystemError = class extends Error {
  code;
  path;
  constructor(code, path, message) {
    super(message);
    this.code = code;
    this.path = path;
  }
};
function isFile(item) {
  return item instanceof Uint8Array || typeof item === "string";
}
function isSymLink(item) {
  return item instanceof SymLink;
}
function isFolder(item) {
  return item !== null && !isFile(item) && !isSymLink(item);
}

// packages/compiler-cli/src/ngtsc/file_system/testing/src/mock_file_system_native.js
import * as os from "os";
var isWindows = os.platform?.() === "win32";
var MockFileSystemNative = class extends MockFileSystem {
  constructor(cwd = "/") {
    super(void 0, cwd);
  }
  // Delegate to the real NodeJSFileSystem for these path related methods
  resolve(...paths) {
    return NodeJSFileSystem.prototype.resolve.call(this, this.pwd(), ...paths);
  }
  dirname(file) {
    return NodeJSFileSystem.prototype.dirname.call(this, file);
  }
  join(basePath, ...paths) {
    return NodeJSFileSystem.prototype.join.call(this, basePath, ...paths);
  }
  relative(from, to) {
    return NodeJSFileSystem.prototype.relative.call(this, from, to);
  }
  basename(filePath, extension) {
    return NodeJSFileSystem.prototype.basename.call(this, filePath, extension);
  }
  isCaseSensitive() {
    return NodeJSFileSystem.prototype.isCaseSensitive.call(this);
  }
  isRooted(path) {
    return NodeJSFileSystem.prototype.isRooted.call(this, path);
  }
  isRoot(path) {
    return NodeJSFileSystem.prototype.isRoot.call(this, path);
  }
  normalize(path) {
    if (isWindows) {
      path = path.replace(/^[\/\\]/i, "C:/");
    }
    return NodeJSFileSystem.prototype.normalize.call(this, path);
  }
  splitPath(path) {
    return path.split(/[\\\/]/);
  }
};

// packages/compiler-cli/src/ngtsc/file_system/testing/src/mock_file_system_posix.js
import * as p from "path";
var MockFileSystemPosix = class extends MockFileSystem {
  resolve(...paths) {
    const resolved = p.posix.resolve(this.pwd(), ...paths);
    return this.normalize(resolved);
  }
  dirname(file) {
    return this.normalize(p.posix.dirname(file));
  }
  join(basePath, ...paths) {
    return this.normalize(p.posix.join(basePath, ...paths));
  }
  relative(from, to) {
    return this.normalize(p.posix.relative(from, to));
  }
  basename(filePath, extension) {
    return p.posix.basename(filePath, extension);
  }
  isRooted(path) {
    return path.startsWith("/");
  }
  splitPath(path) {
    return path.split("/");
  }
  normalize(path) {
    return path.replace(/^[a-z]:\//i, "/").replace(/\\/g, "/");
  }
};

// packages/compiler-cli/src/ngtsc/file_system/testing/src/mock_file_system_windows.js
import * as p2 from "path";
var MockFileSystemWindows = class extends MockFileSystem {
  resolve(...paths) {
    const resolved = p2.win32.resolve(this.pwd(), ...paths);
    return this.normalize(resolved);
  }
  dirname(path) {
    return this.normalize(p2.win32.dirname(path));
  }
  join(basePath, ...paths) {
    return this.normalize(p2.win32.join(basePath, ...paths));
  }
  relative(from, to) {
    return this.normalize(p2.win32.relative(from, to));
  }
  basename(filePath, extension) {
    return p2.win32.basename(filePath, extension);
  }
  isRooted(path) {
    return /^([A-Z]:)?([\\\/]|$)/i.test(path);
  }
  splitPath(path) {
    return path.split(/[\\\/]/);
  }
  normalize(path) {
    return path.replace(/^[\/\\]/i, "C:/").replace(/\\/g, "/");
  }
};

// packages/compiler-cli/src/ngtsc/file_system/testing/src/ngp_known_failures.js
function isNgpSkipEnabled() {
  return process.env["NG_COMPILER_BACKEND"] === "ngp" && process.env["NGP_RUN_KNOWN_FAILURES"] !== "1";
}
function shouldSkipInNgp(fullSpecName) {
  if (!isNgpSkipEnabled()) {
    return false;
  }
  const normalized = fullSpecName.replace(/\s+/g, " ").trim();
  return NGP_REQUIRES_TYPE_CHECKER.has(normalized) || NGP_KNOWN_NGTSC_FAILURES.has(normalized) || NGP_INTENTIONAL_BEHAVIOR_DIFFERENCES.has(normalized);
}
var NGP_REQUIRES_TYPE_CHECKER = /* @__PURE__ */ new Set([
  // Detecting writes to read-only `@let` or `@for` variables in two-way bindings (NG8005)
  // requires a TypeChecker (`isSignalReference`) to distinguish non-signal variables from
  // `WritableSignal` variables (since `[(dir)]="signalVar"` is valid).
  "ngtsc type checking @let declarations should not be able to write to let declaration in a two-way binding",
  "ngtsc type checking for loop blocks should not be able to write to loop template variables in a two-way binding"
]);
var NGP_INTENTIONAL_BEHAVIOR_DIFFERENCES = /* @__PURE__ */ new Set([
  // Design difference, not a bug: when an imported transform function's parameter type references
  // another symbol imported in the external declaration file (rather than a self-contained type),
  // ngp emits `Parameters<typeof i1.transformFn>[0]` instead of re-importing the external symbol.
  "ngtsc behavioral tests input transforms should compile an input with an external transform function",
  "ngtsc behavioral tests input transforms should compile an input with using an ambient type in the transform function",
  // Partial compilation isn't implemented in ngp.
  "ngtsc behavioral tests cycle detection should detect a simple cycle and fatally error if doing partial-compilation",
  // Design difference, not a bug: on an `@Inject` parameter whose type is imported from another
  // file, ngp emits `type: undefined` in `ɵsetClassMetadata` in both compilation modes. Single-file
  // analysis cannot tell an imported class from an imported interface (ngtsc can, via the type
  // checker), and withholding the type is safe because DI uses the `@Inject` token. The
  // cross-file pass deliberately does not upgrade these so that both modes keep the same runtime
  // imports; see the `@Inject` rule in `ng-analyze/src/analyzer/mod.rs`. These specs assert the
  // ngtsc shape (`type: ImportedClass` and a surviving import) for such a parameter.
  "ngtsc behavioral tests should use imported types in setClassMetadata if they can be represented as values",
  "ngtsc behavioral tests should use imported types in setClassMetadata if they can be represented as values and imported as `* as foo`",
  "ngtsc behavioral tests should preserve the types of non-const enums in setClassMetadata",
  // Flat module index generation (`flatModuleOutFile` and `flatModuleId`) is a legacy View Engine
  // feature that won't be ported to ngp for the time being.
  "ngtsc behavioral tests flat module indices should determine the flat module entry-point within multiple root files",
  "ngtsc behavioral tests flat module indices should generate a basic flat module index",
  "ngtsc behavioral tests flat module indices should generate a flat module with an id",
  "ngtsc behavioral tests flat module indices should generate a proper flat module index file when nested",
  "ngtsc behavioral tests flat module indices should report an error when a deeply visible directive is not exported",
  "ngtsc behavioral tests flat module indices should report an error when a deeply visible module is not exported",
  "ngtsc behavioral tests flat module indices should report an error when a flat module index is requested but no entrypoint can be determined",
  "ngtsc behavioral tests flat module indices should report an error when a visible directive is not exported",
  "ngtsc behavioral tests flat module indices should report an error when a visible host directive is not exported",
  // These tests depend on compiler flags that aren't relevant for ngp
  // (`_useHostForImportAndAliasGeneration` and `generateDeepReexports`).
  "ngtsc behavioral tests NgModule export aliasing should escape unusual characters in aliased filenames",
  "ngtsc behavioral tests NgModule export aliasing should use an alias to import a directive from a deep dependency when _useHostForImportAndAliasGeneration is set",
  "ngtsc behavioral tests NgModule export aliasing should write alias ES2015 exports for NgModule exported directives when _useHostForImportAndAliasGeneration is set",
  "ngtsc behavioral tests aliasing re-exports should error when two directives with the same declared name are exported from the same NgModule",
  "ngtsc behavioral tests aliasing re-exports should not error when two directives with the same declared name are exported from the same NgModule, but one is exported from the file directly",
  "ngtsc behavioral tests aliasing re-exports should re-export a directive from a different file under a private symbol name",
  "ngtsc behavioral tests aliasing re-exports should re-export a directive from an exported NgModule under a private symbol name",
  // The two tests check behavior specific to the TS6 source
  // file construction so we don't need to support them.
  "template parse failures should handle TypeScript parse failures gracefully",
  "template parse failures should handle non-Error failures gracefully",
  // Tests TypeScript `structureIsReused` across in-memory ngtsc incremental compilations.
  "ngtsc type checking stability should allow for complete program reuse during incremental compilations",
  // Extended diagnostics that won't be ported to the new compilation model
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when a function in a chain is not invoked",
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when a function in a function is not invoked",
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when a function in an event binding is not invoked",
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when a function is not",
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when a function that returns a function is not invoked",
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when a nested function in a conditional is not invoked",
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when a nested function in an event binding is not invoked",
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when a nested function that uses key read in an event binding is not invoked",
  "UninvokedFunctionInEventBindingFactoryCheck should produce a diagnostic when no function in a conditional is not invoked"
]);
var NGP_KNOWN_NGTSC_FAILURES = /* @__PURE__ */ new Set([
  "import generation should report an error when a library entry-point does not export the symbol",
  "import generation should report an error when using a directive outside of rootDirs",
  // API documentation extraction (`getApiDocumentation`) is not implemented in NGP.
  "ngtsc NgModule docs extraction should extract NgModule info",
  "ngtsc class docs extraction should extract a method with a rest parameter",
  "ngtsc class docs extraction should extract abstract classes",
  "ngtsc class docs extraction should extract class constructor",
  "ngtsc class docs extraction should extract class constructor with overloads",
  "ngtsc class docs extraction should extract class generic parameters",
  "ngtsc class docs extraction should extract class members",
  "ngtsc class docs extraction should extract class method params",
  "ngtsc class docs extraction should extract classes",
  "ngtsc class docs extraction should extract getters and setters",
  "ngtsc class docs extraction should extract inherited getters/setters",
  "ngtsc class docs extraction should extract inherited members",
  "ngtsc class docs extraction should extract inheritence/interface conformance",
  "ngtsc class docs extraction should extract member tags",
  "ngtsc class docs extraction should extract members of a class from .d.ts",
  "ngtsc class docs extraction should extract method generic parameters",
  "ngtsc class docs extraction should extract methods with overloads",
  "ngtsc class docs extraction should extract only once, when discovering abstract methods with overloads",
  "ngtsc class docs extraction should extract public constructor parameters",
  "ngtsc class docs extraction should not extract Angular-internal members",
  "ngtsc class docs extraction should not extract a constructor without parameters",
  "ngtsc class docs extraction should not extract internal member tags",
  "ngtsc class docs extraction should not extract private class members",
  "ngtsc class docs extraction should only mark constructor parameter properties from a parent as inherited",
  "ngtsc common docs extraction should not extract unexported statements",
  "ngtsc constant docs extraction should extract an object literal cast to a const and marked as an enum",
  "ngtsc constant docs extraction should extract an object literal marked as an enum",
  "ngtsc constant docs extraction should extract constants",
  "ngtsc constant docs extraction should extract multiple constant declarations in a single statement",
  "ngtsc constant docs extraction should extract non-primitive constants",
  "ngtsc decorator docs extraction should extract class decorators that define members in an interface",
  "ngtsc decorator docs extraction should extract param decorators",
  "ngtsc decorator docs extraction should extract property decorators",
  "ngtsc decorator docs extraction should extract property decorators with a type alias",
  "ngtsc decorator docs extraction should extract the decorator with some deprecated signatures",
  "ngtsc directive docs extraction selector alias extraction should extract alias from element with attribute selector",
  "ngtsc directive docs extraction selector alias extraction should extract alias from ng-template with attribute selector",
  "ngtsc directive docs extraction selector alias extraction should extract alias from simple attribute selector",
  "ngtsc directive docs extraction selector alias extraction should extract aliases from complex selector with element and multiple attributes",
  "ngtsc directive docs extraction selector alias extraction should extract multiple aliases from multiple attribute selectors",
  "ngtsc directive docs extraction selector alias extraction should handle empty selector",
  "ngtsc directive docs extraction selector alias extraction should not extract aliases from class selector",
  "ngtsc directive docs extraction selector alias extraction should not extract aliases from element-only selector",
  "ngtsc directive docs extraction should extract NgModule component info",
  "ngtsc directive docs extraction should extract NgModule directive info",
  "ngtsc directive docs extraction should extract getters and setters as inputs",
  "ngtsc directive docs extraction should extract input and output info for a component",
  "ngtsc directive docs extraction should extract input and output info for a directive",
  "ngtsc directive docs extraction should extract standalone component info",
  "ngtsc directive docs extraction should extract standalone directive info",
  "ngtsc docs extraction filtering should extract the type declaration if the value declaration is private",
  "ngtsc docs extraction filtering should not extract Angular-private symbols",
  "ngtsc docs: @docsPrivate tag should error if marked as private without reasoning",
  "ngtsc docs: @docsPrivate tag should omit class annotated with `@docsPrivate`",
  "ngtsc docs: @docsPrivate tag should omit constant annotated with `@docsPrivate`",
  "ngtsc docs: @docsPrivate tag should omit function annotated with `@docsPrivate`",
  "ngtsc docs: @docsPrivate tag should omit interface annotated with `@docsPrivate`",
  "ngtsc enum docs extraction should extract enum info with explicit values",
  "ngtsc enum docs extraction should extract enum info without explicit values",
  "ngtsc function docs extraction should extract a function with a rest parameter",
  "ngtsc function docs extraction should extract function generics",
  "ngtsc function docs extraction should extract function with parameters",
  "ngtsc function docs extraction should extract functions",
  "ngtsc function docs extraction should extract imported symbols from other angular packages",
  "ngtsc function docs extraction should extract overloaded functions",
  "ngtsc function docs extraction should extract type predicates as return type of type guards",
  "ngtsc function docs extraction should not extract imported symbols from non angular packages",
  "ngtsc function docs extraction should not extract private symbols",
  "ngtsc function docs extraction should not extract symbols from private packages",
  "ngtsc function docs extraction should prefer implementation docs over overload docs",
  "ngtsc function docs extraction should use overload docs when implementation has no docs",
  "ngtsc initializer API docs extraction function-based should extract container description",
  "ngtsc initializer API docs extraction function-based should extract container tags",
  "ngtsc initializer API docs extraction function-based should extract name",
  "ngtsc initializer API docs extraction function-based should extract top-level call signatures",
  "ngtsc initializer API docs extraction function-based should have an empty list of sub-properties",
  "ngtsc initializer API docs extraction interface-based should extract container description",
  "ngtsc initializer API docs extraction interface-based should extract container tags",
  "ngtsc initializer API docs extraction interface-based should extract individual return types",
  "ngtsc initializer API docs extraction interface-based should extract name",
  "ngtsc initializer API docs extraction interface-based should extract sub-property call signatures",
  "ngtsc initializer API docs extraction interface-based should extract top-level call signatures",
  "ngtsc interface docs extraction should extract a method with a rest parameter",
  "ngtsc interface docs extraction should extract call signatures",
  "ngtsc interface docs extraction should extract getters and setters",
  "ngtsc interface docs extraction should extract inherited getters/setters",
  "ngtsc interface docs extraction should extract inherited members",
  "ngtsc interface docs extraction should extract interface members",
  "ngtsc interface docs extraction should extract interface method params",
  "ngtsc interface docs extraction should extract interfaces",
  "ngtsc interface docs extraction should extract member tags",
  "ngtsc interface docs extraction should extract return type for call signature",
  "ngtsc interface docs extraction should not extract private interface members",
  "ngtsc jsdoc extraction should escape Angular control flow syntax",
  "ngtsc jsdoc extraction should escape decorator names",
  "ngtsc jsdoc extraction should extract a @see jsdoc tag",
  "ngtsc jsdoc extraction should extract a description from a multi-line jsdoc",
  "ngtsc jsdoc extraction should extract a description from a single-line jsdoc",
  "ngtsc jsdoc extraction should extract class member descriptions",
  "ngtsc jsdoc extraction should extract function parameter descriptions",
  "ngtsc jsdoc extraction should extract jsdoc from all types of top-level statement",
  "ngtsc jsdoc extraction should extract jsdoc with a multi-line tags",
  "ngtsc jsdoc extraction should extract jsdoc with a single-line tag",
  "ngtsc jsdoc extraction should extract jsdoc with an empty tag",
  "ngtsc jsdoc extraction should extract jsdoc with custom tags",
  "ngtsc jsdoc extraction should extract raw comment blocks",
  "ngtsc jsdoc extraction should handle a jsdoc with a trailing ()",
  "ngtsc jsdoc extraction should handle a jsdoc with a url",
  "ngtsc pipe docs extraction should extract NgModule pipe info",
  "ngtsc pipe docs extraction should extract standalone pipe info",
  "ngtsc re-export docs extraction should extract info from a named re-export",
  "ngtsc re-export docs extraction should extract info from a transitive re-export",
  "ngtsc re-export docs extraction should extract info from an aggregate re-export",
  "ngtsc re-export docs extraction should extract info from an aliased re-export",
  "ngtsc type alias docs extraction should extract type aliases based on primitives",
  "ngtsc type alias docs extraction should extract type aliases based with generics",
  "ngtsc type alias docs extraction should extract type aliases for objects",
  // `TemplateTypeChecker` Language Service helper queries (`getPrimaryAngularDecorator`,
  // `getOwningNgModule`, `getPotentialPipes`) are not implemented in NGP.
  "full type checking can retrieve candidate pipes` which are out of scope",
  "full type checking supports `getOwningNgModule()` for components",
  "full type checking supports `getOwningNgModule()` for pipes",
  "full type checking supports `getOwningNgModule()` for standalone components (which should be null)",
  "full type checking supports `getPrimaryAngularDecorator()` for NgModules",
  "full type checking supports `getPrimaryAngularDecorator()` for components",
  "full type checking supports `getPrimaryAngularDecorator()` for pipes",
  // Legacy `xi18n` message extraction (`mainXi18n`) is not implemented in NGP.
  "ngtsc xi18n should extract xlf",
  "ngtsc xi18n should extract xlf2",
  "ngtsc xi18n should extract xmb",
  "ngtsc xi18n should not emit js"
]);

// packages/compiler-cli/src/ngtsc/file_system/testing/src/test_helper.js
import ts from "typescript";
var FS_NATIVE = "Native";
var FS_OS_X = "OS/X";
var FS_UNIX = "Unix";
var FS_WINDOWS = "Windows";
var FS_ALL = [FS_OS_X, FS_WINDOWS, FS_UNIX, FS_NATIVE];
function runInEachFileSystemFn(callback) {
  FS_ALL.forEach((os2) => runInFileSystem(os2, callback, false));
}
var counter = 0;
function runInFileSystem(os2, callback, error) {
  describe(`<<FileSystem: ${os2}>>/${counter++}`, () => {
    beforeEach(() => initMockFileSystem(os2));
    afterEach(() => setFileSystem(new InvalidFileSystem()));
    if (isNgpSkipEnabled()) {
      const origDescribe = globalThis.describe;
      const origIt = globalThis.it;
      const suiteStack = [];
      globalThis.describe = (description, specDefinitions) => {
        return origDescribe(description, () => {
          suiteStack.push(description);
          try {
            specDefinitions();
          } finally {
            suiteStack.pop();
          }
        });
      };
      globalThis.it = (expectation, assertion, timeout) => {
        const fullName = [...suiteStack, expectation].join(" ").replace(/\s+/g, " ").trim();
        if (shouldSkipInNgp(fullName)) {
          return globalThis.xit(expectation, assertion, timeout);
        }
        return origIt(expectation, assertion, timeout);
      };
      try {
        callback(os2);
      } finally {
        globalThis.describe = origDescribe;
        globalThis.it = origIt;
      }
    } else {
      callback(os2);
    }
    if (error) {
      afterAll(() => {
        throw new Error(`runInFileSystem limited to ${os2}, cannot pass`);
      });
    }
  });
}
var runInEachFileSystem = runInEachFileSystemFn;
runInEachFileSystem.native = (callback) => runInFileSystem(FS_NATIVE, callback, true);
runInEachFileSystem.osX = (callback) => runInFileSystem(FS_OS_X, callback, true);
runInEachFileSystem.unix = (callback) => runInFileSystem(FS_UNIX, callback, true);
runInEachFileSystem.windows = (callback) => runInFileSystem(FS_WINDOWS, callback, true);
var mockFileSystemLocked = false;
function initMockFileSystem(os2, cwd) {
  if (mockFileSystemLocked) {
    return getFileSystem();
  }
  const fs = createMockFileSystem(os2, cwd);
  setFileSystem(fs);
  monkeyPatchTypeScript(fs);
  return fs;
}
function createMockFileSystem(os2, cwd) {
  switch (os2) {
    case "OS/X":
      return new MockFileSystemPosix(
        /* isCaseSensitive */
        false,
        cwd
      );
    case "Unix":
      return new MockFileSystemPosix(
        /* isCaseSensitive */
        true,
        cwd
      );
    case "Windows":
      return new MockFileSystemWindows(
        /* isCaseSensitive*/
        false,
        cwd
      );
    case "Native":
      return new MockFileSystemNative(cwd);
    default:
      throw new Error("FileSystem not supported");
  }
}
function monkeyPatchTypeScript(fs) {
  ts.sys.fileExists = (path) => {
    const absPath = fs.resolve(path);
    return fs.exists(absPath) && fs.stat(absPath).isFile();
  };
  ts.sys.getCurrentDirectory = () => fs.pwd();
  ts.sys.getDirectories = getDirectories;
  ts.sys.readFile = fs.readFile.bind(fs);
  ts.sys.resolvePath = fs.resolve.bind(fs);
  ts.sys.writeFile = fs.writeFile.bind(fs);
  ts.sys.directoryExists = directoryExists;
  ts.sys.readDirectory = readDirectory;
  function getDirectories(path) {
    return fs.readdir(absoluteFrom(path)).filter((p3) => fs.stat(fs.resolve(path, p3)).isDirectory());
  }
  function getFileSystemEntries(path) {
    const files = [];
    const directories = [];
    const absPath = fs.resolve(path);
    const entries = fs.readdir(absPath);
    for (const entry of entries) {
      if (entry == "." || entry === "..") {
        continue;
      }
      const absPath2 = fs.resolve(path, entry);
      const stat = fs.stat(absPath2);
      if (stat.isDirectory()) {
        directories.push(absPath2);
      } else if (stat.isFile()) {
        files.push(absPath2);
      }
    }
    return { files, directories };
  }
  function realPath(path) {
    return fs.realpath(fs.resolve(path));
  }
  function directoryExists(path) {
    const absPath = fs.resolve(path);
    return fs.exists(absPath) && fs.stat(absPath).isDirectory();
  }
  const tsMatchFiles = ts.matchFiles;
  function readDirectory(path, extensions, excludes, includes, depth) {
    return tsMatchFiles(path, extensions, excludes, includes, fs.isCaseSensitive(), fs.pwd(), depth, getFileSystemEntries, realPath, directoryExists);
  }
}
export {
  ImportedSymbolsTracker,
  MockFileSystem,
  TypeScriptReflectionHost,
  getInitializerApiJitTransform,
  initMockFileSystem
};
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
//# sourceMappingURL=testing.js.map
