/*!
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
export * from './src/metadata';
export * from './src/update_declaration';
export { extractHmrDependenciesFromOutput, PotentialTopLevelReadsVisitor, type HmrCompiledOutput, type HmrDependencies, type HmrReadResolver, } from './src/extract_dependencies';
