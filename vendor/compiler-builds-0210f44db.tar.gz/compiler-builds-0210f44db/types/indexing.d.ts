/**
 * @license Angular v22.4.0-next.0+sha-f3ea683
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

export { AbsoluteSourceSpan, AbstractBoundTemplate, AttributeIdentifier, BoundAttributeIdentifier, DirectiveHostIdentifier, DirectiveReference, ElementIdentifier, IdentifierKind, IndexedComponent, IndexerComponentInfo, IndexerVisitor, IndexingContext, LetDeclarationIdentifier, MethodIdentifier, NodeAdapter, PipeIdentifier, PropertyIdentifier, ReferenceIdentifier, TemplateIdentifier, TemplateNodeIdentifier, TopLevelIdentifier, VariableIdentifier, generateIndexerAnalysis, getIndexerTemplateIdentifiers } from './_index-chunk.js';
