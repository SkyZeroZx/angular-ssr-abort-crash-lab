/**
 * @license Angular v22.4.0-next.0+sha-f3ea683
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

function setAlternateWeakRefImpl(impl) {}

export { setAlternateWeakRefImpl };
//# sourceMappingURL=_weak_ref-chunk.mjs.map
