import { DefaultUrlSerializer, ActivatedRoute, Router, ROUTES, ɵloadChildren as _loadChildren } from '@angular/router';
import { getFirstHeaderValue, normalizeTrustProxyHeaders, sanitizeRequestHeaders, validateRequest } from './_validation-chunk.mjs';
import { APP_BASE_HREF, PlatformLocation } from '@angular/common';
import { ɵConsole as _Console, ApplicationRef, REQUEST, makeEnvironmentProviders, provideEnvironmentInitializer, inject, InjectionToken, ɵENABLE_ROOT_COMPONENT_BOOTSTRAP as _ENABLE_ROOT_COMPONENT_BOOTSTRAP, Compiler, createEnvironmentInjector, EnvironmentInjector, runInInjectionContext, ɵresetCompiledComponents as _resetCompiledComponents, REQUEST_CONTEXT, RESPONSE_INIT, LOCALE_ID } from '@angular/core';
import { platformServer, INITIAL_CONFIG, ɵSERVER_CONTEXT as _SERVER_CONTEXT, ɵrenderInternal as _renderInternal, provideServerRendering as provideServerRendering$1 } from '@angular/platform-server';
import { createProcessor } from 'beasties/runtime';

class ServerAssets {
  manifest;
  constructor(manifest) {
    this.manifest = manifest;
  }
  getServerAsset(path) {
    const asset = this.manifest.assets[path];
    if (!asset) {
      throw new Error(`Server asset '${path}' does not exist.`);
    }
    return asset;
  }
  hasServerAsset(path) {
    return !!this.manifest.assets[path];
  }
  getIndexServerHtml() {
    return this.getServerAsset('index.server.html');
  }
}

const IGNORED_LOGS = new Set(['Angular is running in development mode.']);
class Console extends _Console {
  log(message) {
    if (!IGNORED_LOGS.has(message)) {
      super.log(message);
    }
  }
}

let angularAppManifest;
function setAngularAppManifest(manifest) {
  angularAppManifest = manifest;
}
function getAngularAppManifest() {
  if (!angularAppManifest) {
    throw new Error('Angular app manifest is not set. ' + `Please ensure you are using the '@angular/build:application' builder to build your server application.`);
  }
  return angularAppManifest;
}
let angularAppEngineManifest;
function setAngularAppEngineManifest(manifest) {
  angularAppEngineManifest = manifest;
}
function getAngularAppEngineManifest() {
  if (!angularAppEngineManifest) {
    throw new Error('Angular app engine manifest is not set. ' + `Please ensure you are using the '@angular/build:application' builder to build your server application.`);
  }
  return angularAppEngineManifest;
}

const WILDCARD_SEGMENT = {
  type: 'wildcard'
};
const EMPTY_QUERY_PARAMS = [];
const POSITIONAL_WILDCARD_REGEX = /^\*\d+$/;
function stripTrailingSlash(url) {
  return url.length > 1 && url.at(-1) === '/' ? url.slice(0, -1) : url;
}
function stripLeadingSlash(url) {
  return url.length > 1 && url[0] === '/' ? url.slice(1) : url;
}
function addLeadingSlash(url) {
  return url[0] === '/' ? url : `/${url}`;
}
function addTrailingSlash(url) {
  return url.at(-1) === '/' ? url : `${url}/`;
}
function joinUrlParts(...parts) {
  const normalizedParts = [];
  let suffix = '';
  let lastIndex = parts.length - 1;
  while (lastIndex >= 0 && parts[lastIndex] === '') {
    lastIndex--;
  }
  for (let i = 0; i <= lastIndex; i++) {
    const part = parts[i];
    if (part === '') {
      continue;
    }
    let start = 0;
    let end = part.length;
    if (i === lastIndex) {
      const queryIndex = part.indexOf('?');
      const hashIndex = part.indexOf('#');
      const suffixIndex = queryIndex === -1 ? hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      if (suffixIndex !== -1) {
        suffix = part.slice(suffixIndex);
        end = suffixIndex;
      }
    }
    while (start < end && part[start] === '/') {
      start++;
    }
    while (end > start && part[end - 1] === '/') {
      end--;
    }
    if (start < end) {
      normalizedParts.push(part.slice(start, end));
    }
  }
  return addLeadingSlash(normalizedParts.join('/')) + suffix;
}
function stripIndexHtmlFromURL(url) {
  if (url.pathname.endsWith('/index.html')) {
    const modifiedURL = new URL(url);
    modifiedURL.pathname = modifiedURL.pathname.slice(0, -11);
    return modifiedURL;
  }
  return url;
}
let urlSerializer;
let serializationTree;
function parsePathSegment(segment) {
  if (segment[0] === '*') {
    if (segment.length === 1) {
      return WILDCARD_SEGMENT;
    }
    if (POSITIONAL_WILDCARD_REGEX.test(segment)) {
      return {
        type: 'wildcard',
        index: Number(segment.slice(1))
      };
    }
  } else if (segment[0] === ':' && segment.length > 1) {
    return {
      type: 'param',
      name: segment.slice(1)
    };
  }
  return {
    type: 'static',
    value: segment
  };
}
function parsePathSegments(path) {
  const segments = [];
  let start = 0;
  const length = path.length;
  while (start < length) {
    while (start < length && path[start] === '/') {
      start++;
    }
    if (start >= length) {
      break;
    }
    let end = path.indexOf('/', start);
    if (end === -1) {
      end = length;
    }
    segments.push(parsePathSegment(path.slice(start, end)));
    start = end + 1;
  }
  return segments;
}
function extractPathSegments(path) {
  const segments = [];
  let start = 0;
  const length = path.length;
  while (start < length) {
    while (start < length && path[start] === '/') {
      start++;
    }
    if (start >= length) {
      break;
    }
    let end = path.indexOf('/', start);
    if (end === -1) {
      end = length;
    }
    segments.push(path.slice(start, end));
    start = end + 1;
  }
  return segments;
}
function serializePathSegment(segment) {
  switch (segment.type) {
    case 'static':
      return segment.value;
    case 'param':
      return `:${segment.name}`;
    case 'wildcard':
      return segment.index === undefined ? '*' : `*${segment.index}`;
  }
}
function serializePathSegments(segments) {
  let result = '';
  for (const segment of segments) {
    const value = serializePathSegment(segment);
    if (value) {
      result += '/' + value;
    }
  }
  return result || '/';
}
function parseUrl(url) {
  const queryIndex = url.indexOf('?');
  const hashIndex = url.indexOf('#');
  const suffixIndex = queryIndex === -1 ? hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
  const path = suffixIndex === -1 ? url : url.slice(0, suffixIndex);
  const rawSuffix = suffixIndex === -1 ? '' : url.slice(suffixIndex);
  const segments = parsePathSegments(path);
  const hasDynamicSegments = segments.some(segment => segment.type !== 'static');
  if (rawSuffix[0] === '?' && rawSuffix.includes('=:')) {
    urlSerializer ??= new DefaultUrlSerializer();
    const tree = urlSerializer.parse(rawSuffix);
    const queryParams = [];
    let hasDynamicQueryParams = false;
    for (const [name, value] of Object.entries(tree.queryParams)) {
      if (typeof value === 'string' && value[0] === ':') {
        queryParams.push({
          type: 'param',
          name,
          param: value.slice(1)
        });
        hasDynamicQueryParams = true;
      } else {
        queryParams.push({
          type: 'static',
          name,
          value
        });
      }
    }
    return {
      isAbsolute: path[0] === '/',
      segments,
      queryParams,
      fragment: tree.fragment,
      rawSuffix,
      hasDynamicSegments,
      hasDynamicQueryParams
    };
  }
  return {
    isAbsolute: path[0] === '/',
    segments,
    queryParams: EMPTY_QUERY_PARAMS,
    fragment: hashIndex === -1 ? null : decodeURIComponent(url.slice(hashIndex + 1)),
    rawSuffix,
    hasDynamicSegments,
    hasDynamicQueryParams: false
  };
}
function buildUrlWithParams(toUrl, fromPath, fromSearch) {
  if (toUrl[0] !== '/') {
    throw new Error(`Invalid toUrl: The string must start with a '/'. Received: '${toUrl}'`);
  }
  if (fromPath[0] !== '/') {
    throw new Error(`Invalid fromPath: The string must start with a '/'. Received: '${fromPath}'`);
  }
  if (!toUrl.includes('/*') && (fromSearch === undefined || !toUrl.includes('=:'))) {
    return toUrl;
  }
  const parsed = parseUrl(toUrl);
  if (!parsed.hasDynamicSegments && (fromSearch === undefined || !parsed.hasDynamicQueryParams)) {
    return toUrl;
  }
  let resolvedPath;
  if (parsed.hasDynamicSegments) {
    const fromSegments = extractPathSegments(fromPath);
    let builtPath = '';
    for (let i = 0; i < parsed.segments.length; i++) {
      const segment = parsed.segments[i];
      const value = segment.type === 'wildcard' ? fromSegments[segment.index ?? i] ?? serializePathSegment(segment) : serializePathSegment(segment);
      if (value) {
        builtPath += '/' + value;
      }
    }
    resolvedPath = builtPath || '/';
  } else {
    resolvedPath = serializePathSegments(parsed.segments);
  }
  let suffix = parsed.rawSuffix;
  if (fromSearch !== undefined && parsed.hasDynamicQueryParams) {
    urlSerializer ??= new DefaultUrlSerializer();
    serializationTree ??= urlSerializer.parse('');
    const actualParams = fromSearch ? urlSerializer.parse(fromSearch).queryParams : {};
    const resolvedQueryParams = {};
    for (const param of parsed.queryParams) {
      resolvedQueryParams[param.name] = param.type === 'param' ? actualParams[param.param] : param.value;
    }
    serializationTree.queryParams = resolvedQueryParams;
    serializationTree.fragment = parsed.fragment;
    suffix = urlSerializer.serialize(serializationTree).slice(1);
    serializationTree.queryParams = {};
    serializationTree.fragment = null;
  }
  return resolvedPath + suffix;
}
const MATRIX_PARAMS_REGEX = /;[^/]+/g;
function stripMatrixParams(pathname) {
  return pathname.includes(';') ? pathname.replace(MATRIX_PARAMS_REGEX, '') : pathname;
}

async function renderAngular(html, bootstrap, url, platformProviders, serverContext, signal) {
  if (signal?.aborted) {
    return {
      hasNavigationError: true
    };
  }
  const urlToRender = stripIndexHtmlFromURL(url);
  const platformRef = platformServer([{
    provide: INITIAL_CONFIG,
    useValue: {
      url: urlToRender.href,
      document: html
    }
  }, {
    provide: _SERVER_CONTEXT,
    useValue: serverContext
  }, {
    provide: _Console,
    useFactory: () => new Console()
  }, ...platformProviders]);
  let redirectTo;
  let hasNavigationError = true;
  let renderTimeoutId;
  let destroyPromise;
  let contentPromise;
  let rejectContent;
  const createAbortError = () => new DOMException(`Request for: ${url} was aborted.${signal?.reason ? `\n${signal.reason}` : ''}`, 'AbortError');
  const destroy = () => {
    if (!destroyPromise) {
      clearTimeout(renderTimeoutId);
      rejectContent?.(createAbortError());
      rejectContent = undefined;
      contentPromise = undefined;
      signal?.removeEventListener('abort', abortHandler);
      destroyPromise = asyncDestroyPlatform(platformRef);
    }
    return destroyPromise;
  };
  const abortHandler = () => void destroy();
  try {
    signal?.addEventListener('abort', abortHandler, {
      once: true
    });
    let applicationRef;
    if (isNgModule(bootstrap)) {
      const moduleRef = await platformRef.bootstrapModule(bootstrap);
      if (platformRef.destroyed || moduleRef.injector.destroyed || signal?.aborted) {
        return {
          hasNavigationError: true
        };
      }
      applicationRef = moduleRef.injector.get(ApplicationRef);
    } else {
      applicationRef = await bootstrap({
        platformRef
      });
      if (platformRef.destroyed || applicationRef.destroyed || signal?.aborted) {
        return {
          hasNavigationError: true
        };
      }
    }
    await applicationRef.whenStable();
    if (platformRef.destroyed || applicationRef.destroyed || signal?.aborted) {
      return {
        hasNavigationError: true
      };
    }
    const envInjector = applicationRef.injector;
    const routerIsProvided = !!envInjector.get(ActivatedRoute, null);
    const router = envInjector.get(Router);
    const lastSuccessfulNavigation = router.lastSuccessfulNavigation();
    if (!routerIsProvided) {
      hasNavigationError = false;
    } else if (lastSuccessfulNavigation?.finalUrl) {
      const requestPrefix = envInjector.get(APP_BASE_HREF, null, {
        optional: true
      }) ?? getFirstHeaderValue(envInjector.get(REQUEST, null, {
        optional: true
      })?.headers.get('X-Forwarded-Prefix'));
      const {
        pathname,
        search,
        hash
      } = envInjector.get(PlatformLocation);
      const finalUrl = constructSerializedUrl(router, {
        pathname,
        search,
        hash
      }, requestPrefix);
      const urlToRenderString = constructSerializedUrl(router, urlToRender, requestPrefix);
      if (urlToRenderString !== finalUrl) {
        redirectTo = [pathname, search, hash].join('');
      }
      hasNavigationError = false;
    }
    return {
      destroy,
      hasNavigationError,
      redirectTo,
      content: () => {
        if (destroyPromise || platformRef.destroyed || applicationRef.destroyed || signal?.aborted) {
          void destroy();
          return Promise.reject(createAbortError());
        }
        return contentPromise ??= new Promise((resolve, reject) => {
          rejectContent = reject;
          renderTimeoutId = setTimeout(() => {
            if (destroyPromise || platformRef.destroyed || applicationRef.destroyed || signal?.aborted) {
              rejectContent = undefined;
              void destroy();
              reject(createAbortError());
              return;
            }
            _renderInternal(platformRef, applicationRef).then(renderedHtml => {
              rejectContent = undefined;
              void destroy();
              resolve(renderedHtml);
            }, error => {
              rejectContent = undefined;
              void destroy();
              reject(error);
            });
          }, 0);
        });
      }
    };
  } finally {
    if (hasNavigationError || redirectTo) {
      void destroy();
    }
  }
}
function isNgModule(value) {
  return 'ɵmod' in value;
}
function asyncDestroyPlatform(platformRef) {
  if (platformRef.destroyed) {
    return Promise.resolve();
  }
  return new Promise(resolve => {
    setTimeout(() => {
      try {
        if (!platformRef.destroyed) {
          platformRef.destroy();
        }
      } finally {
        resolve();
      }
    }, 0);
  });
}
function constructSerializedUrl(router, url, prefix) {
  const {
    pathname,
    hash,
    search
  } = url;
  const urlParts = [];
  if (prefix && !addTrailingSlash(pathname).startsWith(addTrailingSlash(prefix))) {
    urlParts.push(joinUrlParts(prefix, pathname));
  } else {
    urlParts.push(stripTrailingSlash(pathname));
  }
  urlParts.push(search, hash);
  const urlTree = router.parseUrl(urlParts.join(''));
  return router.serializeUrl(urlTree);
}

function promiseWithAbort(promise, signal, errorMessagePrefix) {
  return new Promise((resolve, reject) => {
    const abortHandler = () => {
      reject(new DOMException(`${errorMessagePrefix} was aborted.\n${signal.reason}`, 'AbortError'));
    };
    if (signal.aborted) {
      abortHandler();
    } else {
      signal.addEventListener('abort', abortHandler, {
        once: true
      });
    }
    promise.then(resolve).catch(reject).finally(() => {
      signal.removeEventListener('abort', abortHandler);
    });
  });
}

const VALID_REDIRECT_RESPONSE_CODES = new Set([301, 302, 303, 307, 308]);
function isValidRedirectResponseCode(code) {
  return VALID_REDIRECT_RESPONSE_CODES.has(code);
}
function createRedirectResponse(location, status = 302, headers) {
  if (ngDevMode && !isValidRedirectResponseCode(status)) {
    throw new Error(`Invalid redirect status code: ${status}. ` + `Please use one of the following redirect response codes: ${[...VALID_REDIRECT_RESPONSE_CODES.values()].join(', ')}.`);
  }
  const resHeaders = headers instanceof Headers ? headers : new Headers(headers);
  if (ngDevMode && resHeaders.has('location')) {
    console.warn(`Location header "${resHeaders.get('location')}" will be ignored and set to "${location}".`);
  }
  const varyArray = resHeaders.get('Vary')?.split(',') ?? [];
  const varySet = new Set(['X-Forwarded-Prefix']);
  for (const vary of varyArray) {
    const value = vary.trim();
    if (value) {
      varySet.add(value);
    }
  }
  resHeaders.set('Vary', [...varySet].join(', '));
  resHeaders.set('Location', location);
  return new Response(null, {
    status,
    headers: resHeaders
  });
}

const APP_SHELL_ROUTE = 'ng-app-shell';
var ServerRenderingFeatureKind;
(function (ServerRenderingFeatureKind) {
  ServerRenderingFeatureKind[ServerRenderingFeatureKind["AppShell"] = 0] = "AppShell";
  ServerRenderingFeatureKind[ServerRenderingFeatureKind["ServerRoutes"] = 1] = "ServerRoutes";
})(ServerRenderingFeatureKind || (ServerRenderingFeatureKind = {}));
var RenderMode;
(function (RenderMode) {
  RenderMode[RenderMode["Server"] = 0] = "Server";
  RenderMode[RenderMode["Client"] = 1] = "Client";
  RenderMode[RenderMode["Prerender"] = 2] = "Prerender";
})(RenderMode || (RenderMode = {}));
var PrerenderFallback;
(function (PrerenderFallback) {
  PrerenderFallback[PrerenderFallback["Server"] = 0] = "Server";
  PrerenderFallback[PrerenderFallback["Client"] = 1] = "Client";
  PrerenderFallback[PrerenderFallback["None"] = 2] = "None";
})(PrerenderFallback || (PrerenderFallback = {}));
const SERVER_ROUTES_CONFIG = new InjectionToken('SERVER_ROUTES_CONFIG');
function withRoutes(routes) {
  const config = {
    routes
  };
  return {
    ɵkind: ServerRenderingFeatureKind.ServerRoutes,
    ɵproviders: [{
      provide: SERVER_ROUTES_CONFIG,
      useValue: config
    }]
  };
}
function withAppShell(component) {
  const routeConfig = {
    path: APP_SHELL_ROUTE
  };
  if ('ɵcmp' in component) {
    routeConfig.component = component;
  } else {
    routeConfig.loadComponent = component;
  }
  return {
    ɵkind: ServerRenderingFeatureKind.AppShell,
    ɵproviders: [{
      provide: ROUTES,
      useValue: routeConfig,
      multi: true
    }, provideEnvironmentInitializer(() => {
      const config = inject(SERVER_ROUTES_CONFIG);
      config.appShellRoute = APP_SHELL_ROUTE;
    })]
  };
}
function provideServerRendering(...args) {
  let options;
  let features;
  if (hasOptions(args)) {
    const [first, ...rest] = args;
    options = first;
    features = rest;
  } else {
    features = args;
  }
  const providers = [provideServerRendering$1(options)];
  let hasAppShell = false;
  let hasServerRoutes = false;
  for (const {
    ɵkind,
    ɵproviders
  } of features) {
    hasAppShell ||= ɵkind === ServerRenderingFeatureKind.AppShell;
    hasServerRoutes ||= ɵkind === ServerRenderingFeatureKind.ServerRoutes;
    providers.push(...ɵproviders);
  }
  if (!hasServerRoutes && hasAppShell) {
    throw new Error(`Configuration error: found 'withAppShell()' without 'withRoutes()' in the same call to 'provideServerRendering()'. ` + `The 'withAppShell()' function requires 'withRoutes()' to be used.`);
  }
  return makeEnvironmentProviders(providers);
}
function hasOptions(args) {
  const value = args[0];
  return !!value && typeof value === 'object' && !('ɵkind' in value);
}

class RouteTree {
  root = this.createEmptyRouteTreeNode();
  insert(route, metadata) {
    let node = this.root;
    const segments = this.getPathSegments(route);
    const normalizedSegments = [];
    for (const segment of segments) {
      const normalizedSegment = segment[0] === ':' ? '*' : segment;
      let childNode = node.children.get(normalizedSegment);
      if (!childNode) {
        childNode = this.createEmptyRouteTreeNode();
        node.children.set(normalizedSegment, childNode);
      }
      node = childNode;
      normalizedSegments.push(normalizedSegment);
    }
    node.metadata = {
      ...metadata,
      route: addLeadingSlash(normalizedSegments.join('/'))
    };
  }
  match(route) {
    const segments = this.getPathSegments(route);
    return this.traverseBySegments(segments)?.metadata;
  }
  toObject() {
    return Array.from(this.traverse());
  }
  static fromObject(value) {
    const tree = new RouteTree();
    for (const {
      route,
      ...metadata
    } of value) {
      tree.insert(route, metadata);
    }
    return tree;
  }
  *traverse(node = this.root) {
    if (node.metadata) {
      yield node.metadata;
    }
    for (const childNode of node.children.values()) {
      yield* this.traverse(childNode);
    }
  }
  getPathSegments(route) {
    return route.split('/').filter(Boolean).map(decodeURIComponent);
  }
  traverseBySegments(segments, node = this.root, currentIndex = 0) {
    if (currentIndex >= segments.length) {
      return node.metadata ? node : node.children.get('**');
    }
    if (!node.children.size) {
      return undefined;
    }
    const segment = segments[currentIndex];
    const exactMatch = node.children.get(segment);
    if (exactMatch) {
      const match = this.traverseBySegments(segments, exactMatch, currentIndex + 1);
      if (match) {
        return match;
      }
    }
    const wildcardMatch = node.children.get('*');
    if (wildcardMatch) {
      const match = this.traverseBySegments(segments, wildcardMatch, currentIndex + 1);
      if (match) {
        return match;
      }
    }
    return node.children.get('**');
  }
  createEmptyRouteTreeNode() {
    return {
      children: new Map()
    };
  }
}

const IS_DISCOVERING_ROUTES = new InjectionToken(typeof ngDevMode === 'undefined' || ngDevMode ? 'IS_DISCOVERING_ROUTES' : '', {
  providedIn: 'platform',
  factory: () => false
});
const MODULE_PRELOAD_MAX = 10;
const CATCH_ALL_REGEXP = /\/(\*\*)$/;
const URL_PARAMETER_REGEXP = /(?<!\\):([^/]+)/;
const URL_PARAMETER_GLOBAL_REGEXP = new RegExp(URL_PARAMETER_REGEXP, 'g');
const INVALID_PATH_SEGMENT_CHARS_REGEXP = /[/\\?#;*%\p{Control}]/u;
async function* handleRoute(options) {
  try {
    const {
      metadata,
      currentRoutePath,
      parentRoute,
      baseHref,
      route,
      compiler,
      parentInjector,
      serverConfigRouteTree,
      entryPointToBrowserMapping,
      invokeGetPrerenderParams,
      includePrerenderFallbackRoutes
    } = options;
    const {
      redirectTo,
      loadChildren,
      loadComponent,
      children,
      ɵentryName
    } = route;
    if (ɵentryName && (loadComponent || loadChildren)) {
      appendPreloadToMetadata(ɵentryName, entryPointToBrowserMapping, metadata);
    }
    const parentRoutes = new Map();
    if (typeof redirectTo === 'string') {
      const routeSegments = parsePathSegments(joinUrlParts(baseHref, currentRoutePath));
      metadata.redirectTo = resolveRedirectTo(parentRoute, route, redirectTo, paramName => {
        for (let i = routeSegments.length - 1; i >= 0; i--) {
          const segment = routeSegments[i];
          if (segment.type === 'param' && segment.name === paramName) {
            return {
              type: 'wildcard',
              index: i
            };
          }
        }
        return WILDCARD_SEGMENT;
      });
      metadata.relativeRedirect = redirectTo[0] !== '/' ? true : undefined;
    }
    if (metadata.renderMode === RenderMode.Prerender) {
      for await (const result of handleSSGRoute(serverConfigRouteTree, route, parentRoute, metadata, parentInjector, invokeGetPrerenderParams, includePrerenderFallbackRoutes)) {
        if ('error' in result) {
          yield result;
        } else {
          parentRoutes.set(result.route, result);
        }
      }
    } else if (redirectTo !== undefined && metadata.status && !isValidRedirectResponseCode(metadata.status)) {
      yield {
        error: `The '${metadata.status}' status code is not a valid redirect response code. ` + `Please use one of the following redirect response codes: ${[...VALID_REDIRECT_RESPONSE_CODES.values()].join(', ')}.`
      };
    } else {
      parentRoutes.set(metadata.route, metadata);
    }
    let childRoutes = children;
    let childInjector = parentInjector;
    if (!childRoutes?.length && loadChildren) {
      const routeInjector = route.providers ? createEnvironmentInjector(route.providers, parentInjector.get(EnvironmentInjector), `Route: ${route.path}`) : parentInjector;
      const loadedChildRoutes = await _loadChildren(route, compiler, routeInjector);
      if (loadedChildRoutes) {
        childRoutes = loadedChildRoutes.routes;
        childInjector = loadedChildRoutes.injector ?? routeInjector;
      }
    }
    if (!childRoutes?.length) {
      yield* parentRoutes.values();
      return;
    }
    const childResults = [];
    const overriddenParentRoutes = new Set();
    const traverseChildRoutes = traverseRoutesConfig({
      ...options,
      routes: childRoutes,
      parentInjector: childInjector,
      parentRoute: currentRoutePath,
      parentPreloads: metadata.preload
    });
    for await (const result of traverseChildRoutes) {
      if ('error' in result) {
        childResults.push(result);
        continue;
      }
      if (parentRoutes.has(result.route)) {
        if (!overriddenParentRoutes.has(result.route)) {
          overriddenParentRoutes.add(result.route);
          parentRoutes.set(result.route, result);
        }
      } else {
        childResults.push(result);
      }
    }
    yield* parentRoutes.values();
    yield* childResults;
  } catch (error) {
    yield {
      error: `Error in handleRoute for '${options.currentRoutePath}': ${error.message}`
    };
  }
}
async function* traverseRoutesConfig(options) {
  const {
    routes: routeConfigs,
    parentPreloads,
    parentRoute,
    serverConfigRouteTree
  } = options;
  for (const route of routeConfigs) {
    const {
      matcher,
      path = matcher ? '**' : ''
    } = route;
    const currentRoutePath = joinUrlParts(parentRoute, path);
    if (matcher && serverConfigRouteTree) {
      const matches = [];
      for (const matchedMetaData of serverConfigRouteTree.traverse()) {
        if (matchedMetaData.route.startsWith(currentRoutePath)) {
          matches.push(matchedMetaData);
        }
      }
      if (!matches.length) {
        const matchedMetaData = serverConfigRouteTree.match(currentRoutePath);
        if (matchedMetaData) {
          matches.push(matchedMetaData);
        }
      }
      for (const matchedMetaData of matches) {
        matchedMetaData.presentInClientRouter = true;
        if (matchedMetaData.renderMode === RenderMode.Prerender) {
          yield {
            error: `The route '${stripLeadingSlash(currentRoutePath)}' is set for prerendering but has a defined matcher. ` + `Routes with matchers cannot use prerendering. Please specify a different 'renderMode'.`
          };
          continue;
        }
        yield* handleRoute({
          ...options,
          currentRoutePath,
          route,
          metadata: {
            ...matchedMetaData,
            preload: parentPreloads,
            route: matchedMetaData.route,
            presentInClientRouter: undefined
          }
        });
      }
      if (!matches.length) {
        yield {
          error: `The route '${stripLeadingSlash(currentRoutePath)}' has a defined matcher but does not ` + 'match any route in the server routing configuration. Please ensure this route is added to the server routing configuration.'
        };
      }
      continue;
    }
    let matchedMetaData;
    if (serverConfigRouteTree) {
      matchedMetaData = serverConfigRouteTree.match(currentRoutePath);
      if (!matchedMetaData) {
        yield {
          error: `The '${stripLeadingSlash(currentRoutePath)}' route does not match any route defined in the server routing configuration. ` + 'Please ensure this route is added to the server routing configuration.'
        };
        continue;
      }
      matchedMetaData.presentInClientRouter = true;
    }
    yield* handleRoute({
      ...options,
      metadata: {
        renderMode: RenderMode.Prerender,
        ...matchedMetaData,
        preload: parentPreloads,
        route: currentRoutePath,
        presentInClientRouter: undefined
      },
      currentRoutePath,
      route
    });
  }
}
function appendPreloadToMetadata(entryName, entryPointToBrowserMapping, metadata) {
  const existingPreloads = metadata.preload ?? [];
  if (!entryPointToBrowserMapping || existingPreloads.length >= MODULE_PRELOAD_MAX) {
    return;
  }
  const preload = entryPointToBrowserMapping[entryName];
  if (!preload?.length) {
    return;
  }
  const combinedPreloads = new Set(existingPreloads);
  for (const href of preload) {
    combinedPreloads.add(href);
    if (combinedPreloads.size === MODULE_PRELOAD_MAX) {
      break;
    }
  }
  metadata.preload = Array.from(combinedPreloads);
}
async function* handleSSGRoute(serverConfigRouteTree, route, parentRoute, metadata, parentInjector, invokeGetPrerenderParams, includePrerenderFallbackRoutes) {
  if (metadata.renderMode !== RenderMode.Prerender) {
    throw new Error(`'handleSSGRoute' was called for a route which rendering mode is not prerender.`);
  }
  const {
    route: currentRoutePath,
    fallback,
    ...meta
  } = metadata;
  const getPrerenderParams = 'getPrerenderParams' in meta ? meta.getPrerenderParams : undefined;
  if ('getPrerenderParams' in meta) {
    delete meta['getPrerenderParams'];
  }
  const isCatchAllRoute = CATCH_ALL_REGEXP.test(currentRoutePath);
  if (isCatchAllRoute && !getPrerenderParams || !isCatchAllRoute && !URL_PARAMETER_REGEXP.test(currentRoutePath)) {
    yield {
      ...meta,
      route: currentRoutePath
    };
    return;
  }
  if (invokeGetPrerenderParams) {
    if (!getPrerenderParams) {
      yield {
        error: `The '${stripLeadingSlash(currentRoutePath)}' route uses prerendering and includes parameters, but 'getPrerenderParams' ` + `is missing. Please define 'getPrerenderParams' function for this route in your server routing configuration ` + `or specify a different 'renderMode'.`
      };
      return;
    }
    if (serverConfigRouteTree) {
      const catchAllRoutePath = isCatchAllRoute ? currentRoutePath : joinUrlParts(currentRoutePath, '**');
      const match = serverConfigRouteTree.match(catchAllRoutePath);
      if (match && match.renderMode === RenderMode.Prerender && !('getPrerenderParams' in match)) {
        serverConfigRouteTree.insert(catchAllRoutePath, {
          ...match,
          presentInClientRouter: true,
          getPrerenderParams
        });
      }
    }
    const redirectTo = typeof route.redirectTo === 'string' ? route.redirectTo : undefined;
    const parameters = await runInInjectionContext(parentInjector, () => getPrerenderParams());
    try {
      for (const params of parameters) {
        const replacer = handlePrerenderParamsReplacement(params, currentRoutePath);
        const routeWithResolvedParams = currentRoutePath.replace(URL_PARAMETER_GLOBAL_REGEXP, replacer).replace(CATCH_ALL_REGEXP, replacer);
        yield {
          ...meta,
          route: routeWithResolvedParams,
          redirectTo: redirectTo === undefined ? undefined : resolveRedirectTo(parentRoute.replace(URL_PARAMETER_GLOBAL_REGEXP, replacer), route, redirectTo, paramName => ({
            type: 'static',
            value: params[paramName]
          }))
        };
      }
    } catch (error) {
      yield {
        error: `${error.message}`
      };
      return;
    }
  }
  if (includePrerenderFallbackRoutes && (fallback !== PrerenderFallback.None || !invokeGetPrerenderParams)) {
    yield {
      ...meta,
      route: currentRoutePath,
      renderMode: fallback === PrerenderFallback.Client ? RenderMode.Client : RenderMode.Server
    };
  }
}
function handlePrerenderParamsReplacement(params, currentRoutePath) {
  return match => {
    const parameterName = match.slice(1);
    const value = params[parameterName];
    if (typeof value !== 'string') {
      throw new Error(`The 'getPrerenderParams' function defined for the '${stripLeadingSlash(currentRoutePath)}' route ` + `returned a non-string value for parameter '${parameterName}'. ` + `Please make sure the 'getPrerenderParams' function returns values for all parameters ` + 'specified in this route.');
    }
    const segments = parameterName === '**' ? value ? value.split('/') : [] : [value];
    if (!segments.every(isPathSegment)) {
      throw new Error(`The 'getPrerenderParams' function defined for the '${stripLeadingSlash(currentRoutePath)}' route ` + `returned an invalid value '${value}' for parameter '${parameterName}'. ` + `Please make sure the value is a valid URL path${parameterName === '**' ? '' : ' segment'} ` + 'without dot segments or reserved characters.');
    }
    return parameterName === '**' ? `/${value}` : value;
  };
}
function isPathSegment(segment) {
  let decoded;
  try {
    decoded = decodeURIComponent(segment);
  } catch {
    return false;
  }
  return decoded.length > 0 && decoded !== '.' && decoded !== '..' && decoded[0] !== ':' && !INVALID_PATH_SEGMENT_CHARS_REGEXP.test(decoded);
}
function resolveRedirectTo(parentRoute, route, redirectTo, resolveParam) {
  if (redirectTo[0] === '/' && (route.matcher || !redirectTo.includes('/:'))) {
    return redirectTo;
  }
  const parsedRedirect = parseUrl(redirectTo);
  let resolvedSegments = parsedRedirect.segments;
  if (!route.matcher && parsedRedirect.hasDynamicSegments) {
    const routeSegments = parsePathSegments(route.path ?? '');
    resolvedSegments = resolvedSegments.map(segment => {
      if (segment.type !== 'param') {
        return segment;
      }
      if (!routeSegments.some(s => s.type === 'param' && s.name === segment.name)) {
        throw new Error(`Cannot redirect to '${redirectTo}'. Cannot find ':${segment.name}'.`);
      }
      return resolveParam(segment.name);
    });
  }
  if (parsedRedirect.isAbsolute) {
    return serializePathSegments(resolvedSegments) + parsedRedirect.rawSuffix;
  }
  const parentSegments = parsePathSegments(parentRoute).map(segment => segment.type === 'param' ? WILDCARD_SEGMENT : segment);
  return serializePathSegments([...parentSegments, ...resolvedSegments]);
}
function buildServerConfigRouteTree({
  routes,
  appShellRoute
}) {
  const serverRoutes = [...routes];
  if (appShellRoute !== undefined) {
    serverRoutes.unshift({
      path: appShellRoute,
      renderMode: RenderMode.Prerender
    });
  }
  const serverConfigRouteTree = new RouteTree();
  const errors = [];
  for (const {
    path,
    ...metadata
  } of serverRoutes) {
    if (path[0] === '/') {
      errors.push(`Invalid '${path}' route configuration: the path cannot start with a slash.`);
      continue;
    }
    if ('getPrerenderParams' in metadata && (path.includes('/*/') || path.endsWith('/*'))) {
      errors.push(`Invalid '${path}' route configuration: 'getPrerenderParams' cannot be used with a '*' route.`);
      continue;
    }
    serverConfigRouteTree.insert(path, metadata);
  }
  return {
    serverConfigRouteTree,
    errors
  };
}
async function getRoutesFromAngularRouterConfig(bootstrap, document, url, invokeGetPrerenderParams = false, includePrerenderFallbackRoutes = true, entryPointToBrowserMapping = undefined) {
  const {
    protocol,
    host
  } = url;
  const platformRef = platformServer([{
    provide: INITIAL_CONFIG,
    useValue: {
      document,
      url: `${protocol}//${host}/`
    }
  }, {
    provide: _Console,
    useFactory: () => new Console()
  }, {
    provide: _ENABLE_ROOT_COMPONENT_BOOTSTRAP,
    useValue: false
  }, {
    provide: IS_DISCOVERING_ROUTES,
    useValue: true
  }]);
  try {
    let applicationRef;
    if (isNgModule(bootstrap)) {
      const moduleRef = await platformRef.bootstrapModule(bootstrap);
      applicationRef = moduleRef.injector.get(ApplicationRef);
    } else {
      applicationRef = await bootstrap({
        platformRef
      });
    }
    const injector = applicationRef.injector;
    const router = injector.get(Router);
    router.navigationTransitions.afterPreactivation()?.next?.();
    await applicationRef.whenStable();
    const errors = [];
    const rawBaseHref = injector.get(APP_BASE_HREF, null, {
      optional: true
    }) ?? injector.get(PlatformLocation).getBaseHrefFromDOM();
    const {
      pathname: baseHref
    } = new URL(rawBaseHref, 'http://localhost');
    const compiler = injector.get(Compiler);
    const serverRoutesConfig = injector.get(SERVER_ROUTES_CONFIG, null, {
      optional: true
    });
    let serverConfigRouteTree;
    if (serverRoutesConfig) {
      const result = buildServerConfigRouteTree(serverRoutesConfig);
      serverConfigRouteTree = result.serverConfigRouteTree;
      errors.push(...result.errors);
    }
    if (errors.length) {
      return {
        baseHref,
        routes: [],
        errors
      };
    }
    const routesResults = [];
    if (router.config.length) {
      const traverseRoutes = traverseRoutesConfig({
        routes: router.config,
        compiler,
        parentInjector: injector,
        parentRoute: '',
        baseHref,
        serverConfigRouteTree,
        invokeGetPrerenderParams,
        includePrerenderFallbackRoutes,
        entryPointToBrowserMapping
      });
      const seenRoutes = new Set();
      for await (const routeMetadata of traverseRoutes) {
        if ('error' in routeMetadata) {
          errors.push(routeMetadata.error);
          continue;
        }
        const routePath = routeMetadata.route;
        if (!seenRoutes.has(routePath)) {
          routesResults.push(routeMetadata);
          seenRoutes.add(routePath);
        }
      }
      await new Promise(resolve => setTimeout(resolve, 0));
      if (serverConfigRouteTree) {
        for (const {
          route,
          presentInClientRouter
        } of serverConfigRouteTree.traverse()) {
          if (presentInClientRouter || route.endsWith('/**')) {
            continue;
          }
          errors.push(`The '${stripLeadingSlash(route)}' server route does not match any routes defined in the Angular ` + `routing configuration (typically provided as a part of the 'provideRouter' call). ` + 'Please make sure that the mentioned server route is present in the Angular routing configuration.');
        }
      }
    } else {
      const rootRouteMetadata = serverConfigRouteTree?.match('') ?? {
        route: '',
        renderMode: RenderMode.Prerender
      };
      routesResults.push({
        ...rootRouteMetadata,
        route: ''
      });
    }
    return {
      baseHref,
      routes: routesResults,
      errors,
      appShellRoute: serverRoutesConfig?.appShellRoute
    };
  } finally {
    platformRef.destroy();
  }
}
function extractRoutesAndCreateRouteTree(options) {
  const {
    url,
    manifest = getAngularAppManifest(),
    invokeGetPrerenderParams = false,
    includePrerenderFallbackRoutes = true,
    signal
  } = options;
  async function extract() {
    const routeTree = new RouteTree();
    const document = await new ServerAssets(manifest).getIndexServerHtml().text();
    const bootstrap = await manifest.bootstrap();
    const {
      baseHref,
      appShellRoute,
      routes,
      errors
    } = await getRoutesFromAngularRouterConfig(bootstrap, document, url, invokeGetPrerenderParams, includePrerenderFallbackRoutes, manifest.entryPointToBrowserMapping);
    for (const {
      route,
      ...metadata
    } of routes) {
      if (metadata.redirectTo !== undefined) {
        metadata.redirectTo = joinUrlParts(baseHref, metadata.redirectTo);
      }
      for (const [key, value] of Object.entries(metadata)) {
        if (value === undefined) {
          delete metadata[key];
        }
      }
      const fullRoute = joinUrlParts(baseHref, route);
      routeTree.insert(fullRoute, metadata);
    }
    return {
      appShellRoute,
      routeTree,
      errors
    };
  }
  return signal ? promiseWithAbort(extract(), signal, 'Routes extraction') : extract();
}

class Hooks {
  store = new Map();
  async run(name, context) {
    const hooks = this.store.get(name);
    switch (name) {
      case 'html:transform:pre':
        {
          if (!hooks) {
            return context.html;
          }
          const ctx = {
            ...context
          };
          for (const hook of hooks) {
            ctx.html = await hook(ctx);
          }
          return ctx.html;
        }
      default:
        throw new Error(`Running hook "${name}" is not supported.`);
    }
  }
  on(name, handler) {
    const hooks = this.store.get(name);
    if (hooks) {
      hooks.push(handler);
    } else {
      this.store.set(name, [handler]);
    }
  }
  has(name) {
    return !!this.store.get(name)?.length;
  }
}

class ServerRouter {
  routeTree;
  constructor(routeTree) {
    this.routeTree = routeTree;
  }
  static #extractionPromise;
  static from(manifest, url) {
    if (manifest.routes) {
      const routeTree = RouteTree.fromObject(manifest.routes);
      return Promise.resolve(new ServerRouter(routeTree));
    }
    ServerRouter.#extractionPromise ??= extractRoutesAndCreateRouteTree({
      url,
      manifest
    }).then(({
      routeTree,
      errors
    }) => {
      if (errors.length > 0) {
        throw new Error('Error(s) occurred while extracting routes:\n' + errors.map(error => `- ${error}`).join('\n'));
      }
      return new ServerRouter(routeTree);
    }).finally(() => {
      ServerRouter.#extractionPromise = undefined;
    });
    return ServerRouter.#extractionPromise;
  }
  match(url) {
    let {
      pathname
    } = stripIndexHtmlFromURL(url);
    pathname = stripMatrixParams(pathname);
    return this.routeTree.match(pathname);
  }
}

const WELL_KNOWN_NON_ANGULAR_URLS = new Set(['/favicon.ico', '/.well-known/appspecific/com.chrome.devtools.json']);
const SERVER_CONTEXT_VALUE = {
  [RenderMode.Prerender]: 'ssg',
  [RenderMode.Server]: 'ssr',
  [RenderMode.Client]: ''
};
class AngularServerApp {
  options;
  allowStaticRouteRender;
  hooks;
  constructor(options = {}) {
    this.options = options;
    this.allowStaticRouteRender = this.options.allowStaticRouteRender ?? false;
    this.hooks = options.hooks ?? new Hooks();
  }
  manifest = getAngularAppManifest();
  assets = new ServerAssets(this.manifest);
  router;
  inlineCriticalCssProcessor;
  boostrap;
  textEncoder = new TextEncoder();
  async handle(request, requestContext) {
    const url = new URL(request.url);
    if (WELL_KNOWN_NON_ANGULAR_URLS.has(url.pathname)) {
      return null;
    }
    this.router ??= await ServerRouter.from(this.manifest, url);
    const matchedRoute = this.router.match(url);
    if (!matchedRoute) {
      return null;
    }
    const {
      redirectTo,
      relativeRedirect,
      status,
      renderMode,
      headers
    } = matchedRoute;
    if (redirectTo !== undefined) {
      const location = joinUrlParts(getFirstHeaderValue(request.headers.get('X-Forwarded-Prefix')) ?? '', buildUrlWithParams(redirectTo, url.pathname, relativeRedirect ? undefined : url.search));
      return createRedirectResponse(relativeRedirect ? location + url.search : location, status, headers);
    }
    if (renderMode === RenderMode.Prerender) {
      const response = await this.handleServe(request, matchedRoute);
      if (response) {
        return response;
      }
    }
    return promiseWithAbort(this.handleRendering(request, matchedRoute, requestContext), request.signal, `Request for: ${request.url}`);
  }
  async handleServe(request, matchedRoute) {
    const {
      headers,
      renderMode
    } = matchedRoute;
    if (renderMode !== RenderMode.Prerender) {
      return null;
    }
    const {
      method
    } = request;
    if (method !== 'GET' && method !== 'HEAD') {
      return null;
    }
    const assetPath = this.buildServerAssetPathFromRequest(request);
    const {
      manifest: {
        locale
      },
      assets
    } = this;
    if (!assets.hasServerAsset(assetPath)) {
      return null;
    }
    const {
      text,
      hash,
      size
    } = assets.getServerAsset(assetPath);
    const etag = `"${hash}"`;
    return request.headers.get('if-none-match') === etag ? new Response(undefined, {
      status: 304,
      statusText: 'Not Modified'
    }) : new Response(await text(), {
      headers: {
        'Content-Length': size.toString(),
        'ETag': etag,
        'Content-Type': 'text/html;charset=UTF-8',
        ...(locale !== undefined ? {
          'Content-Language': locale
        } : {}),
        ...headers
      }
    });
  }
  async handleRendering(request, matchedRoute, requestContext) {
    if (request.signal.aborted) {
      return null;
    }
    const {
      renderMode,
      headers,
      status,
      preload
    } = matchedRoute;
    if (!this.allowStaticRouteRender && renderMode === RenderMode.Prerender) {
      return null;
    }
    const url = new URL(request.url);
    const platformProviders = [];
    const {
      manifest: {
        bootstrap,
        locale
      },
      assets
    } = this;
    const responseInit = {
      status,
      headers: new Headers({
        'Content-Type': 'text/html;charset=UTF-8',
        ...(locale !== undefined ? {
          'Content-Language': locale
        } : {}),
        ...headers
      })
    };
    if (renderMode === RenderMode.Server) {
      platformProviders.push({
        provide: REQUEST,
        useValue: request
      }, {
        provide: REQUEST_CONTEXT,
        useValue: requestContext
      }, {
        provide: RESPONSE_INIT,
        useValue: responseInit
      });
    } else if (renderMode === RenderMode.Client) {
      let html = await this.assets.getServerAsset('index.csr.html').text();
      if (request.signal.aborted) {
        return null;
      }
      html = await this.runTransformsOnHtml(html, url, preload);
      return new Response(html, responseInit);
    }
    if (locale !== undefined) {
      platformProviders.push({
        provide: LOCALE_ID,
        useValue: locale
      });
    }
    this.boostrap ??= await bootstrap();
    if (request.signal.aborted) {
      return null;
    }
    let html = await assets.getIndexServerHtml().text();
    if (request.signal.aborted) {
      return null;
    }
    html = await this.runTransformsOnHtml(html, url, preload);
    if (request.signal.aborted) {
      return null;
    }
    const result = await renderAngular(html, this.boostrap, url, platformProviders, SERVER_CONTEXT_VALUE[renderMode], request.signal);
    if (result.hasNavigationError || request.signal.aborted) {
      return null;
    }
    if (result.redirectTo) {
      return createRedirectResponse(result.redirectTo, responseInit.status, responseInit.headers);
    }
    if (renderMode === RenderMode.Prerender) {
      const renderedHtml = await result.content();
      if (request.signal.aborted) {
        return null;
      }
      const finalHtml = this.inlineCriticalCss(renderedHtml);
      return new Response(finalHtml, responseInit);
    }
    const stream = new ReadableStream({
      start: async controller => {
        try {
          let renderedHtml = await result.content();
          if (request.signal.aborted) {
            throw new DOMException(`Request for: ${request.url} was aborted.${request.signal.reason ? `\n${request.signal.reason}` : ''}`, 'AbortError');
          }
          renderedHtml = this.inlineCriticalCss(renderedHtml);
          controller.enqueue(this.textEncoder.encode(renderedHtml));
          controller.close();
        } catch (error) {
          await result.destroy();
          controller.error(error);
        }
      },
      cancel: () => result.destroy()
    });
    return new Response(stream, responseInit);
  }
  inlineCriticalCss(html) {
    const {
      criticalCssPlans,
      nonce
    } = this.manifest;
    if (!criticalCssPlans?.length) {
      return html;
    }
    try {
      this.inlineCriticalCssProcessor ??= createProcessor([...criticalCssPlans], {
        preload: 'media-script',
        nonce,
        preloadFonts: true,
        inlineFonts: true,
        noscriptFallback: true,
        cache: true,
        logger: {
          warn: console.warn
        }
      }).process;
      return this.inlineCriticalCssProcessor(html);
    } catch (error) {
      console.error('An error occurred while inlining critical CSS.', error);
      return html;
    }
  }
  buildServerAssetPathFromRequest(request) {
    let {
      pathname: assetPath
    } = new URL(request.url);
    try {
      assetPath = decodeURIComponent(assetPath);
    } catch {}
    if (!assetPath.endsWith('/index.html')) {
      assetPath = joinUrlParts(assetPath, 'index.html');
    }
    const {
      baseHref
    } = this.manifest;
    if (baseHref.length > 1 && assetPath.startsWith(baseHref)) {
      assetPath = assetPath.slice(baseHref.length);
    }
    return stripLeadingSlash(assetPath);
  }
  async runTransformsOnHtml(html, url, preload) {
    if (this.hooks.has('html:transform:pre')) {
      html = await this.hooks.run('html:transform:pre', {
        html,
        url
      });
    }
    if (preload?.length) {
      html = appendPreloadHintsToHtml(html, preload);
    }
    return html;
  }
}
let angularServerApp;
function getOrCreateAngularServerApp(options) {
  return angularServerApp ??= new AngularServerApp(options);
}
function destroyAngularServerApp() {
  if (typeof ngDevMode === 'undefined' || ngDevMode) {
    _resetCompiledComponents();
  }
  angularServerApp = undefined;
}
function appendPreloadHintsToHtml(html, preload) {
  const bodyCloseIdx = html.lastIndexOf('</body>');
  if (bodyCloseIdx === -1) {
    return html;
  }
  return [html.slice(0, bodyCloseIdx), ...preload.map(val => `<link rel="modulepreload" href="${val}">`), html.slice(bodyCloseIdx)].join('\n');
}

function getPotentialLocaleIdFromUrl(url, basePath) {
  const {
    pathname
  } = url;
  let start = basePath.length;
  if (pathname[start] === '/') {
    start++;
  }
  let end = pathname.indexOf('/', start);
  if (end === -1) {
    end = pathname.length;
  }
  return pathname.slice(start, end);
}
function parseLanguageHeader(header) {
  if (header === '*') {
    return new Map([['*', 1]]);
  }
  const parsedValues = header.split(',').map(item => {
    const [locale, qualityValue] = item.split(';', 2).map(v => v.trim());
    let quality = qualityValue?.startsWith('q=') ? parseFloat(qualityValue.slice(2)) : undefined;
    if (typeof quality !== 'number' || isNaN(quality) || quality < 0 || quality > 1) {
      quality = 1;
    }
    return [locale, quality];
  }).sort(([_localeA, qualityA], [_localeB, qualityB]) => qualityB - qualityA);
  return new Map(parsedValues);
}
function getPreferredLocale(header, supportedLocales) {
  if (supportedLocales.length < 2) {
    return supportedLocales[0];
  }
  const parsedLocales = parseLanguageHeader(header);
  if (parsedLocales.size === 0 || parsedLocales.size === 1 && parsedLocales.has('*')) {
    return supportedLocales[0];
  }
  const normalizedSupportedLocales = new Map();
  for (const locale of supportedLocales) {
    normalizedSupportedLocales.set(normalizeLocale(locale), locale);
  }
  let bestMatch;
  const qualityZeroNormalizedLocales = new Set();
  for (const [locale, quality] of parsedLocales) {
    const normalizedLocale = normalizeLocale(locale);
    if (quality === 0) {
      qualityZeroNormalizedLocales.add(normalizedLocale);
      continue;
    }
    if (normalizedSupportedLocales.has(normalizedLocale)) {
      return normalizedSupportedLocales.get(normalizedLocale);
    }
    if (bestMatch !== undefined) {
      continue;
    }
    const [languagePrefix] = normalizedLocale.split('-', 1);
    for (const supportedLocale of normalizedSupportedLocales.keys()) {
      if (supportedLocale.startsWith(languagePrefix)) {
        bestMatch = normalizedSupportedLocales.get(supportedLocale);
        break;
      }
    }
  }
  if (bestMatch !== undefined) {
    return bestMatch;
  }
  for (const [normalizedLocale, locale] of normalizedSupportedLocales) {
    if (!qualityZeroNormalizedLocales.has(normalizedLocale)) {
      return locale;
    }
  }
}
function normalizeLocale(locale) {
  return locale.toLowerCase();
}

class AngularAppEngine {
  static ɵallowStaticRouteRender = false;
  static ɵdisableAllowedHostsCheck = false;
  static ɵhooks = new Hooks();
  manifest = getAngularAppEngineManifest();
  allowedHosts;
  supportedLocales = Object.keys(this.manifest.supportedLocales);
  trustProxyHeaders;
  entryPointsCache = new Map();
  constructor(options) {
    this.allowedHosts = this.getAllowedHosts(options);
    this.trustProxyHeaders = normalizeTrustProxyHeaders(options?.trustProxyHeaders);
  }
  getAllowedHosts(options) {
    const allowedHosts = new Set([...(options?.allowedHosts ?? []), ...this.manifest.allowedHosts]);
    if (allowedHosts.has('*')) {
      console.warn('Allowing all hosts via "*" is a security risk. This configuration should only be used when ' + 'validation for "Host" and "X-Forwarded-Host" headers is performed in another layer, such as a load balancer or reverse proxy. ' + 'For more information see: https://angular.dev/best-practices/security#preventing-server-side-request-forgery-ssrf');
    }
    return allowedHosts;
  }
  async handle(request, requestContext) {
    const allowedHost = this.allowedHosts;
    const securedRequest = sanitizeRequestHeaders(request, this.trustProxyHeaders);
    try {
      validateRequest(securedRequest, allowedHost, AngularAppEngine.ɵdisableAllowedHostsCheck);
    } catch (error) {
      return this.handleValidationError(securedRequest.url, error);
    }
    const serverApp = await this.getAngularServerAppForRequest(securedRequest);
    if (serverApp) {
      return serverApp.handle(securedRequest, requestContext);
    }
    if (this.supportedLocales.length > 1) {
      return this.redirectBasedOnAcceptLanguage(securedRequest);
    }
    return null;
  }
  redirectBasedOnAcceptLanguage(request) {
    const {
      basePath,
      supportedLocales
    } = this.manifest;
    const {
      pathname
    } = new URL(request.url);
    if (pathname !== basePath) {
      return null;
    }
    const preferredLocale = getPreferredLocale(request.headers.get('Accept-Language') || '*', this.supportedLocales);
    if (preferredLocale) {
      const subPath = supportedLocales[preferredLocale];
      if (subPath !== undefined) {
        const prefix = getFirstHeaderValue(request.headers.get('X-Forwarded-Prefix')) ?? '';
        return createRedirectResponse(joinUrlParts(prefix, pathname, subPath), 302, {
          'Vary': 'Accept-Language'
        });
      }
    }
    return null;
  }
  async getAngularServerAppForRequest(request) {
    const url = new URL(request.url);
    const entryPoint = await this.getEntryPointExportsForUrl(url);
    if (!entryPoint) {
      return null;
    }
    const ɵgetOrCreateAngularServerApp = entryPoint.ɵgetOrCreateAngularServerApp;
    const serverApp = ɵgetOrCreateAngularServerApp({
      allowStaticRouteRender: AngularAppEngine.ɵallowStaticRouteRender,
      hooks: AngularAppEngine.ɵhooks
    });
    return serverApp;
  }
  getEntryPointExports(potentialLocale) {
    const cachedEntryPoint = this.entryPointsCache.get(potentialLocale);
    if (cachedEntryPoint) {
      return cachedEntryPoint;
    }
    const {
      entryPoints
    } = this.manifest;
    const entryPoint = entryPoints[potentialLocale];
    if (!entryPoint) {
      return undefined;
    }
    const entryPointExports = entryPoint();
    this.entryPointsCache.set(potentialLocale, entryPointExports);
    return entryPointExports;
  }
  getEntryPointExportsForUrl(url) {
    const {
      basePath,
      supportedLocales
    } = this.manifest;
    if (this.supportedLocales.length === 1) {
      return this.getEntryPointExports(supportedLocales[this.supportedLocales[0]]);
    }
    const potentialLocale = getPotentialLocaleIdFromUrl(url, basePath);
    return this.getEntryPointExports(potentialLocale) ?? this.getEntryPointExports('');
  }
  handleValidationError(url, error) {
    const errorMessage = error.message;
    console.error(`ERROR: Bad Request ("${url}").\n` + errorMessage + '\n\nFor more information, see https://angular.dev/best-practices/security#preventing-server-side-request-forgery-ssrf');
    return new Response(errorMessage, {
      status: 400,
      statusText: 'Bad Request',
      headers: {
        'Content-Type': 'text/plain'
      }
    });
  }
}

function createRequestHandler(handler) {
  handler['__ng_request_handler__'] = true;
  return handler;
}

export { AngularAppEngine, IS_DISCOVERING_ROUTES, PrerenderFallback, RenderMode, createRequestHandler, provideServerRendering, withAppShell, withRoutes, destroyAngularServerApp as ɵdestroyAngularServerApp, extractRoutesAndCreateRouteTree as ɵextractRoutesAndCreateRouteTree, getOrCreateAngularServerApp as ɵgetOrCreateAngularServerApp, getRoutesFromAngularRouterConfig as ɵgetRoutesFromAngularRouterConfig, setAngularAppEngineManifest as ɵsetAngularAppEngineManifest, setAngularAppManifest as ɵsetAngularAppManifest };
//# sourceMappingURL=ssr.mjs.map
