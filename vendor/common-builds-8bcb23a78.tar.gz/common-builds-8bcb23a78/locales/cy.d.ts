/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
declare function plural(val: number): number;
declare const _default: (string | number | number[] | string[][] | (string | undefined)[] | typeof plural | {
    BDT: (string | undefined)[];
    BWP: (string | undefined)[];
    BYN: (string | undefined)[];
    HKD: string[];
    JPY: string[];
    KRW: (string | undefined)[];
    PHP: (string | undefined)[];
    THB: string[];
    TWD: string[];
    USD: string[];
    XXX: never[];
    ZAR: (string | undefined)[];
    ZMW: (string | undefined)[];
})[];
export default _default;
