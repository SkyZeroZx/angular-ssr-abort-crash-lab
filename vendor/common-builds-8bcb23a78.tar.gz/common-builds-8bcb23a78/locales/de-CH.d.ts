/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
declare function plural(val: number): number;
declare const _default: (string | number | number[] | string[][] | (string | undefined)[] | typeof plural | {
    ATS: string[];
    AUD: string[];
    BGM: string[];
    BGO: string[];
    BYN: (string | undefined)[];
    CUC: (string | undefined)[];
    DEM: string[];
    EUR: never[];
    FKP: (string | undefined)[];
    GHS: (string | undefined)[];
    GNF: (string | undefined)[];
    KMF: (string | undefined)[];
    PHP: (string | undefined)[];
    RON: (string | undefined)[];
    RUR: (string | undefined)[];
    RWF: (string | undefined)[];
    SYP: (string | undefined)[];
    THB: string[];
    TWD: string[];
    XXX: never[];
    ZMW: (string | undefined)[];
} | undefined)[];
export default _default;
