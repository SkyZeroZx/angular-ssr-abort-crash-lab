/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
declare function plural(val: number): number;
declare const _default: (string | number | number[] | string[][] | (string | undefined)[] | typeof plural | {
    AUD: string[];
    BTN: string[];
    ILS: (string | undefined)[];
    JPY: string[];
    KRW: string[];
    THB: string[];
    USD: string[];
    XAF: never[];
} | undefined)[];
export default _default;
